from s4os.core.risk import (
    compose_full_risk,
    compose_geometric_linear_risk,
    compose_geometric_logistic_risk,
    compose_geometric_product_risk,
)


def test_geometric_risks_are_unit_interval():
    kwargs = dict(novelty=0.1, collar_unit=0.95, margin_score=0.9)
    for fn in (compose_geometric_product_risk, compose_geometric_linear_risk, compose_geometric_logistic_risk):
        val = fn(**kwargs)
        assert 0 <= val <= 1


def test_full_risk_requires_attractor_source():
    assert compose_full_risk(geometric_risk=0.8, attractor_score=None, attractor_source="none") is None
    assert compose_full_risk(geometric_risk=0.8, attractor_score=0.9, attractor_source="none") is None
    val = compose_full_risk(geometric_risk=0.8, attractor_score=0.9, attractor_source="condition_label")
    assert val is not None and 0 <= val <= 1
