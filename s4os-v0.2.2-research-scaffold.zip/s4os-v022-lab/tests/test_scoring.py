from s4os.core.config import RiskConfig, S4OSConfig
from s4os.core.types import TraceRecord
from s4os.scoring.engine import ScoreEngine


def make_rec(step, update, attractor=None, source="none"):
    return TraceRecord(
        run_id="r",
        prompt_id="p",
        model_id="m",
        step=step,
        update=update,
        top_logit_values=[10.0, 1.0, 0.5, 0.0],
        adapter_type="synthetic",
        adapter_semantics="unit_test_update_vector",
        attractor_source=source,
        attractor_score=attractor,
    )


def test_no_full_interrupt_without_attractor():
    engine = ScoreEngine(config=S4OSConfig())
    rows = [make_rec(i, [1.0, 0.0]) for i in range(6)]
    scores = list(engine.score_many(rows))
    assert all(s.full_risk is None for s in scores)
    assert all(s.attractor_source == "none" for s in scores)
    assert not any(s.interrupt for s in scores)


def test_full_interrupt_with_attractor_and_streak():
    engine = ScoreEngine(config=S4OSConfig())
    rows = [make_rec(i, [1.0, 0.0], attractor=1.0, source="condition_label") for i in range(8)]
    scores = list(engine.score_many(rows))
    assert any(s.full_risk is not None for s in scores)
    assert any(s.interrupt for s in scores)


def test_risk_formula_selection_linear():
    config = S4OSConfig(risk=RiskConfig(risk_formula="linear"))
    engine = ScoreEngine(config=config)
    score = engine.score_one(make_rec(0, [1.0, 0.0]))
    assert score.risk_formula == "linear"
    assert score.geometric_risk == score.geometric_linear_risk
