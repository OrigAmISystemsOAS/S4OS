import pytest

from s4os.core.types import TraceRecord


def test_trace_record_roundtrip_with_attractor_source():
    rec = TraceRecord(
        run_id="r",
        prompt_id="p",
        model_id="m",
        step=0,
        update=[1.0, 2.0],
        top_logit_values=[3.0, 1.0],
        label=1,
        adapter_type="synthetic",
        adapter_semantics="synthetic_update_vector",
        attractor_source="condition_label",
        attractor_score=0.5,
    )
    obj = rec.to_dict()
    rec2 = TraceRecord.from_dict(obj)
    assert rec2.attractor_score == 0.5
    assert rec2.attractor_source == "condition_label"
    assert rec2.has_valid_attractor


def test_trace_rejects_bad_label():
    rec = TraceRecord(
        run_id="r",
        prompt_id="p",
        model_id="m",
        step=0,
        update=[1.0, 2.0],
        top_logit_values=[3.0, 1.0],
        label=2,
    )
    with pytest.raises(ValueError):
        rec.validate()


def test_trace_rejects_attractor_score_without_source():
    rec = TraceRecord(
        run_id="r",
        prompt_id="p",
        model_id="m",
        step=0,
        update=[1.0, 2.0],
        top_logit_values=[3.0, 1.0],
        attractor_score=0.4,
        attractor_source="none",
    )
    with pytest.raises(ValueError):
        rec.validate()
