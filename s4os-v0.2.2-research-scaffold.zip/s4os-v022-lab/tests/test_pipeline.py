from pathlib import Path

from s4os.data.schemas import load_scores, load_traces, save_scores, save_traces
from s4os.eval.reports import summarize_scores
from s4os.eval.synthetic import generate_synthetic_traces
from s4os.scoring.engine import ScoreEngine


def test_synthetic_pipeline(tmp_path: Path):
    traces = list(generate_synthetic_traces(n_prompts=6, steps=8, dim=16, seed=1))
    trace_path = tmp_path / "traces.jsonl"
    score_path = tmp_path / "scores.jsonl"
    assert save_traces(str(trace_path), traces) == 48
    loaded = load_traces(str(trace_path))
    scores = list(ScoreEngine().score_many(loaded))
    assert save_scores(str(score_path), scores) == 48
    loaded_scores = load_scores(str(score_path))
    report = summarize_scores(loaded_scores)
    assert report["n_records"] == 48
    assert "binary_full_risk" in report
    assert report["attractor_sources"] == ["condition_label"]


def test_no_attractor_pipeline_keeps_full_risk_none(tmp_path: Path):
    traces = list(generate_synthetic_traces(n_prompts=4, steps=6, dim=8, seed=2, include_attractor=False))
    scores = list(ScoreEngine().score_many(traces))
    assert all(s.full_risk is None for s in scores)
    report = summarize_scores(scores)
    assert report["full_risk_valid_records"] == 0
    assert report["full_risk_mean"] is None
