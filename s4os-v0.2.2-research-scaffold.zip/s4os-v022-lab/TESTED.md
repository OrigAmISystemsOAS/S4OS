# Local Test Report for S4OS v0.2.2

Environment: Python 3.13 sandbox.

## Unit tests

```bash
python -m compileall -q src tests
PYTHONPATH=src pytest -q
```

Result:

```text
19 passed in 0.18s
```

## Editable install

```bash
python -m pip install -e . --no-deps
s4os --help
```

Result: editable install and CLI entrypoint available.

## End-to-end synthetic pipeline

```bash
s4os synthetic --out artifacts/traces/synthetic.jsonl --n-prompts 40 --steps 30 --dim 64 --seed 42
s4os score --traces artifacts/traces/synthetic.jsonl --out artifacts/scores/synthetic_product_scores.jsonl --risk-formula product
s4os score --traces artifacts/traces/synthetic.jsonl --out artifacts/scores/synthetic_linear_scores.jsonl --risk-formula linear
s4os score --traces artifacts/traces/synthetic.jsonl --out artifacts/scores/synthetic_logistic_scores.jsonl --risk-formula logistic
s4os report --scores artifacts/scores/synthetic_product_scores.jsonl --out artifacts/reports/synthetic_product_report.json
```

Result:

```text
1200 trace records generated
1200 score records per formula generated
```

Product-report sanity values:

```text
full_risk_valid_records: 1200
product geometric AUROC/AUPRC: 0.75561 / 0.81748
linear geometric AUROC/AUPRC: 0.79309 / 0.84416
logistic geometric AUROC/AUPRC: 0.79431 / 0.84503
full-risk AUROC/AUPRC: 0.87565 / 0.91720
warn_count: 20
interrupt_count: 0
```

These are synthetic diagnostic numbers, not evidence for real model behavior.

## No-attractor boundary check

```bash
s4os synthetic --out artifacts/traces/no_attractor.jsonl --n-prompts 8 --steps 8 --dim 16 --seed 7 --no-attractor
s4os score --traces artifacts/traces/no_attractor.jsonl --out artifacts/scores/no_attractor_scores.jsonl
s4os report --scores artifacts/scores/no_attractor_scores.jsonl --out artifacts/reports/no_attractor_report.json
```

Result:

```text
full_risk_valid_records: 0
full_risk_mean: null
attractor_sources: ["none"]
interrupt_count: 0
warn_count: 0
```

This confirms that v0.2.2 does not fabricate full risk when no independent attractor source exists.
