# Roadmap

## v0.2.2 - implemented

- Attractor-source taxonomy.
- Adapter-semantics fields.
- Product, linear, and logistic geometric-risk baselines.
- Full-risk anti-circularity check.
- Reports with risk formulas, adapter types, and attractor sources.

## v0.3 - next empirical milestone

- Real prompt sets for factual sycophancy pressure and healthy high-confidence controls.
- Trace extraction on small open models.
- Report metric separation: AUROC/AUPRC/FPR by model and adapter.
- Train/test split discipline for any learned probe.

## v0.4 - attractor probe milestone

- `trained_probe` pipeline with strict feature separation from novelty/collar/margin.
- Calibration metrics: ECE, Brier score, AUROC, AUPRC.
- Comparison against condition labels and human labels.

## v0.5 - recovery milestone

- Candidate branch generation.
- Offline recovery reranking evaluation.
- Latency and quality measurements.
- No production claim until recovery improves outcomes under controlled tests.
