# Trace Schema

S4OS v0.2.2 uses explicit trace and score schemas.

## TraceRecord v2

Each JSONL line is one token-step trace record:

```json
{
  "schema_version": "s4os.trace.v2",
  "run_id": "run-001",
  "prompt_id": "p-001",
  "model_id": "synthetic-v0.2.2",
  "step": 0,
  "adapter_type": "synthetic",
  "adapter_semantics": "synthetic_update_vector_with_programmed_directional_freezing",
  "attractor_source": "condition_label",
  "attractor_score": 0.82,
  "update": [0.1, 0.2, -0.3],
  "top_logit_values": [8.1, 6.0, 4.2],
  "top_logit_ids": [123, 456, 789],
  "condition": "freezing",
  "label": 1,
  "metadata": {}
}
```

## Attractor source

Allowed values:

- `none`
- `condition_label`
- `human_label`
- `external_classifier`
- `trained_probe`

If `attractor_source == "none"`, `attractor_score` must be `null` and full risk is not computed.

## Adapter type

Allowed values:

- `synthetic`
- `hf_hidden_state_difference`
- `exact_residual_hook`
- `transformer_lens_hook`
- `state_space_delta`
- `black_box_surface`
- `unknown`

Adapter semantics must be explicitly described on every trace.
