# S4OS v0.2.2 Research Scaffold

**S4OS** is a research scaffold for testing the *directional-freezing* hypothesis in language-model generation traces.

This repository is intentionally narrow and explicit. It does **not** claim to be a production safety kernel, a validated sycophancy detector, or a completed recovery system. It provides a lab-grade instrumentation path:

1. extract or synthesize token-level residual-like / hidden-state update traces;
2. record adapter semantics for every update vector;
3. compute directional-freezing trajectory metrics;
4. compute geometric-risk baselines without pretending to have an attractor probe;
5. compute full risk only when an independent attractor source is present;
6. produce reproducible evaluation reports and ablations.

## What changed in v0.2.2

v0.2.2 hardens three validity boundaries raised during review:

1. **Attractor-source discipline.** Every attractor score has an explicit source: `none`, `condition_label`, `human_label`, `external_classifier`, or `trained_probe`. Full risk is unavailable when the source is `none`.
2. **Adapter-semantics discipline.** Every trace records `adapter_type` and `adapter_semantics`. A Hugging Face hidden-state difference is not silently treated as an exact residual hook.
3. **Risk-baseline discipline.** The scorer reports product, linear, and logistic geometric-risk baselines. The selected formula is stored on every score record and summarized in reports.

## Implemented

- Pure NumPy metric core:
  - orthogonal update novelty;
  - collar persistence;
  - normalized top-logit margin;
  - top-k entropy approximation.
- Geometric risk baselines:
  - product;
  - linear;
  - fixed logistic.
- Full risk only when independent attractor evidence is present.
- Typed v2 trace and score schemas.
- JSONL trace I/O.
- Streaming score engine with per-run/prompt state.
- Synthetic benchmark generator for healthy vs. directional-freezing traces.
- Reporting utilities with AUROC/AUPRC/FPR/TPR and baseline comparisons.
- CLI entrypoint: `s4os`.
- Optional Hugging Face hidden-state-difference extractor.
- Unit tests for metrics, schemas, risk, scoring, CLI, synthetic pipeline, and reports.

## Deliberately not implemented

- No fake natural-language “are you sure?” probe.
- No heuristic surface sycophancy detector in the core package.
- No claim that hidden-state differences are exact residual-stream hooks.
- No pre-commit recovery claim until branch generation and reranking are empirically implemented.
- No universal sycophancy detector claim.

## Install

```bash
pip install -e ".[dev]"
```

For optional Hugging Face extraction:

```bash
pip install -e ".[dev,hf]"
```

## Quickstart

Generate synthetic traces with a condition-label attractor proxy:

```bash
s4os synthetic --out artifacts/traces/synthetic.jsonl --n-prompts 40 --steps 30 --dim 64 --seed 42
```

Score traces with the product risk formula:

```bash
s4os score --traces artifacts/traces/synthetic.jsonl --out artifacts/scores/synthetic_scores.jsonl --risk-formula product
```

Create a report:

```bash
s4os report --scores artifacts/scores/synthetic_scores.jsonl --out artifacts/reports/synthetic_report.json
```

Boundary test: generate traces without any attractor proxy. Full risk should remain unavailable.

```bash
s4os synthetic --out artifacts/traces/no_attractor.jsonl --n-prompts 8 --steps 8 --dim 16 --seed 7 --no-attractor
s4os score --traces artifacts/traces/no_attractor.jsonl --out artifacts/scores/no_attractor_scores.jsonl
s4os report --scores artifacts/scores/no_attractor_scores.jsonl --out artifacts/reports/no_attractor_report.json
```

Run tests:

```bash
pytest -q
```

## Core interpretation

v0.2.2 computes a selected geometric risk and all baseline risks:

```text
R_product  = collar^alpha * (1 - novelty)^beta * margin^eta
R_linear   = weighted_mean(collar, 1 - novelty, margin)
R_logistic = sigmoid(b0 + bC*collar + bN*(1-novelty) + bM*margin)
```

The selected geometric risk is chosen by `--risk-formula`. Full risk exists only when an independent attractor source exists:

```text
full_risk = selected_geometric_risk * attractor_score^gamma
```

If `attractor_source == "none"`, then:

```text
full_risk = None
```

This is the anti-circularity boundary. Geometry alone does not become a sycophancy-risk claim.

## Trace schema excerpt

```json
{
  "schema_version": "s4os.trace.v2",
  "run_id": "run-001",
  "prompt_id": "p-001",
  "model_id": "synthetic-v0.2.2",
  "step": 0,
  "adapter_type": "synthetic",
  "adapter_semantics": "synthetic_update_vector_with_programmed_directional_freezing",
  "attractor_source": "condition_label",
  "attractor_score": 0.82,
  "update": [0.1, 0.2, -0.3],
  "top_logit_values": [8.1, 6.0, 4.2],
  "top_logit_ids": [123, 456, 789],
  "condition": "freezing",
  "label": 1
}
```

## Adapter semantics

The generic Hugging Face adapter computes:

```text
Delta h_l,t = hidden_states[l + 1][:, t, :] - hidden_states[l][:, t, :]
```

and records:

```text
adapter_type = "hf_hidden_state_difference"
adapter_semantics = "mean_hidden_states_lplus1_minus_l_not_exact_residual_hook"
```

Exact residual adapters should be model-specific and should record their semantics explicitly.

## Defensible paper claim

> We release an instrumentation scaffold for evaluating whether low orthogonal novelty and high directional persistence in residual-like / hidden-state update trajectories are predictive of overconfident agreement failures during generation.

Non-defensible claim:

> We solve sycophancy or provide a universal runtime safety kernel.

## License

Apache-2.0.
