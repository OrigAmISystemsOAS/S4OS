# Quality Bar

S4OS v0.2.2 is held to a research-scaffold quality bar, not a production safety-kernel quality bar.

## Required boundaries

- Full risk must never be computed when `attractor_source == "none"`.
- An attractor score must have an explicit source.
- Hidden-state differences must not be described as exact residual hooks.
- Every score record must identify the selected risk formula.
- Reports must include adapter types, attractor sources, and risk formulas.

## Tests expected before release

```bash
python -m compileall -q src tests
pytest -q
s4os synthetic --out artifacts/traces/synthetic.jsonl --n-prompts 40 --steps 30 --dim 64 --seed 42
s4os score --traces artifacts/traces/synthetic.jsonl --out artifacts/scores/synthetic_scores.jsonl --risk-formula product
s4os report --scores artifacts/scores/synthetic_scores.jsonl --out artifacts/reports/synthetic_report.json
s4os synthetic --out artifacts/traces/no_attractor.jsonl --n-prompts 8 --steps 8 --dim 16 --seed 7 --no-attractor
s4os score --traces artifacts/traces/no_attractor.jsonl --out artifacts/scores/no_attractor_scores.jsonl
s4os report --scores artifacts/scores/no_attractor_scores.jsonl --out artifacts/reports/no_attractor_report.json
```

## Not acceptable

- Marketing claims that the repo is a production guardrail.
- Reporting synthetic AUROC as evidence for real models.
- Treating condition labels as trained attractor probes.
- Comparing adapters without naming adapter semantics.
