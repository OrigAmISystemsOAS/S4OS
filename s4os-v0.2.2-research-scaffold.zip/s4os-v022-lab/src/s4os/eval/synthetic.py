# SPDX-License-Identifier: Apache-2.0
"""Synthetic trace generation.

The synthetic benchmark is not evidence for real model behavior. It is a
sanity-check harness for metric behavior and pipeline tests.
"""

from __future__ import annotations

from collections.abc import Iterable

import numpy as np

from s4os.core.types import TraceRecord


def _top_logits(rng: np.random.Generator, *, margin_high: bool, k: int = 50) -> list[float]:
    vals = rng.normal(0.0, 1.0, size=k)
    vals.sort()
    vals = vals[::-1]
    if margin_high:
        vals[0] = vals[1] + float(rng.uniform(4.0, 7.0))
    else:
        vals[0] = vals[1] + float(rng.uniform(0.1, 1.0))
    return vals.tolist()


def generate_synthetic_traces(
    *,
    n_prompts: int = 20,
    steps: int = 24,
    dim: int = 64,
    seed: int = 0,
    model_id: str = "synthetic-v0.2.2",
    include_attractor: bool = True,
) -> Iterable[TraceRecord]:
    """Yield healthy and freezing traces.

    Half of the prompts are healthy controls with moderate directional diversity.
    Half simulate directional freezing by gradually reducing orthogonal noise while
    increasing margin. If ``include_attractor`` is true, the trace includes a
    condition-label attractor proxy. This is explicitly not a trained probe.
    """

    if n_prompts < 2:
        raise ValueError("n_prompts must be >= 2")
    if steps < 3:
        raise ValueError("steps must be >= 3")
    if dim < 2:
        raise ValueError("dim must be >= 2")

    rng = np.random.default_rng(seed)
    for p in range(n_prompts):
        is_freezing = p >= n_prompts // 2
        condition = "freezing" if is_freezing else "healthy"
        label = 1 if is_freezing else 0
        run_id = f"synthetic-seed-{seed}"
        prompt_id = f"p-{p:04d}"
        base = rng.normal(size=dim)
        base = base / np.linalg.norm(base)

        for step in range(steps):
            if is_freezing:
                frac = step / max(1, steps - 1)
                noise_scale = 0.8 * (1.0 - frac) + 0.015
                update = base + noise_scale * rng.normal(size=dim)
                margin_high = step >= steps // 3
                attractor = min(1.0, 0.25 + 0.75 * frac)
            else:
                update = rng.normal(size=dim)
                margin_high = step % 5 == 0
                attractor = float(rng.uniform(0.0, 0.25))

            attractor_source = "condition_label" if include_attractor else "none"
            attractor_score = attractor if include_attractor else None
            top_logits = _top_logits(rng, margin_high=margin_high)
            yield TraceRecord(
                run_id=run_id,
                prompt_id=prompt_id,
                model_id=model_id,
                step=step,
                update=np.asarray(update, dtype=float).tolist(),
                top_logit_values=top_logits,
                top_logit_ids=list(range(len(top_logits))),
                token_id=int(step),
                token_text=f"tok_{step}",
                condition=condition,
                label=label,
                adapter_type="synthetic",
                adapter_semantics="synthetic_update_vector_with_programmed_directional_freezing",
                attractor_source=attractor_source,
                attractor_score=attractor_score,
                metadata={"synthetic_generator": "s4os.eval.synthetic.generate_synthetic_traces"},
            )
