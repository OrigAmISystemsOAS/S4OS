# SPDX-License-Identifier: Apache-2.0
"""Streaming trace scoring engine."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable

from s4os.core.config import S4OSConfig
from s4os.core.metrics import collar_persistence, entropy_from_top_logits, normalized_margin, orthogonal_novelty
from s4os.core.risk import (
    compose_full_risk,
    compose_geometric_linear_risk,
    compose_geometric_logistic_risk,
    compose_geometric_product_risk,
    select_geometric_risk,
)
from s4os.core.types import ScoreRecord, TraceRecord
from s4os.core.windows import PromptState, VectorWindow


@dataclass
class ScoreEngine:
    """Compute S4OS metrics over ordered trace records.

    State is keyed by ``(run_id, prompt_id)``. Records should be sorted by step
    within each key. If unsorted records are supplied, metrics remain defined but
    no longer correspond to chronological generation.
    """

    config: S4OSConfig = field(default_factory=S4OSConfig)
    _states: dict[tuple[str, str], PromptState] = field(default_factory=dict, init=False)

    def __post_init__(self) -> None:
        self.config.validate()

    def reset(self) -> None:
        self._states.clear()

    def _state_for(self, rec: TraceRecord) -> PromptState:
        key = (rec.run_id, rec.prompt_id)
        if key not in self._states:
            self._states[key] = PromptState(window=VectorWindow(maxlen=self.config.max_history))
        return self._states[key]

    def score_one(self, rec: TraceRecord, *, commit: bool = True) -> ScoreRecord:
        rec.validate()
        state = self._state_for(rec)
        hist = state.window.to_list()
        mc = self.config.metric
        rc = self.config.risk

        novelty, low_energy = orthogonal_novelty(
            rec.update,
            hist,
            k=mc.history_k,
            eps=mc.energy_eps,
        )
        collar_raw, collar_unit = collar_persistence(
            rec.update,
            hist,
            k=mc.history_k,
            eps=mc.energy_eps,
            map_to_unit=mc.map_collar_to_unit_interval,
        )
        margin, margin_z = normalized_margin(
            rec.top_logit_values,
            top_k=mc.top_k_margin,
            a=mc.margin_sigmoid_a,
            b=mc.margin_sigmoid_b,
            eps=mc.energy_eps,
        )
        entropy = entropy_from_top_logits(rec.top_logit_values)

        product = compose_geometric_product_risk(
            novelty=novelty,
            collar_unit=collar_unit,
            margin_score=margin,
            alpha_collar=rc.alpha_collar,
            beta_low_novelty=rc.beta_low_novelty,
            eta_margin=rc.eta_margin,
            energy_gate=not low_energy,
        )
        linear = compose_geometric_linear_risk(
            novelty=novelty,
            collar_unit=collar_unit,
            margin_score=margin,
            w_collar=rc.w_collar,
            w_low_novelty=rc.w_low_novelty,
            w_margin=rc.w_margin,
            energy_gate=not low_energy,
        )
        logistic = compose_geometric_logistic_risk(
            novelty=novelty,
            collar_unit=collar_unit,
            margin_score=margin,
            b0=rc.logistic_b0,
            b_collar=rc.logistic_b_collar,
            b_low_novelty=rc.logistic_b_low_novelty,
            b_margin=rc.logistic_b_margin,
            energy_gate=not low_energy,
        )
        geometric_risk = select_geometric_risk(
            formula=rc.risk_formula,
            product=product,
            linear=linear,
            logistic=logistic,
        )
        full_risk = compose_full_risk(
            geometric_risk=geometric_risk,
            attractor_score=rec.attractor_score,
            attractor_source=rec.attractor_source,
            gamma_attractor=rc.gamma_attractor,
        )

        if full_risk is not None:
            warn = full_risk >= rc.full_warn_threshold
            over = full_risk >= rc.full_interrupt_threshold
        else:
            warn = geometric_risk >= rc.geometric_warn_threshold
            over = rc.allow_geometric_interrupt and warn

        if over:
            state.increment_streak()
        else:
            state.reset_streak()

        interrupt = bool(over and state.risk_streak >= rc.min_interrupt_streak)

        score = ScoreRecord(
            run_id=rec.run_id,
            prompt_id=rec.prompt_id,
            model_id=rec.model_id,
            step=rec.step,
            condition=rec.condition,
            label=rec.label,
            adapter_type=rec.adapter_type,
            adapter_semantics=rec.adapter_semantics,
            attractor_source=rec.attractor_source,
            novelty=novelty,
            collar_raw=collar_raw,
            collar_unit=collar_unit,
            margin_score=margin,
            margin_z=margin_z,
            entropy_topk=entropy,
            low_energy_fault=low_energy,
            attractor_score=rec.attractor_score,
            geometric_product_risk=product,
            geometric_linear_risk=linear,
            geometric_logistic_risk=logistic,
            geometric_risk=geometric_risk,
            risk_formula=rc.risk_formula,
            full_risk=full_risk,
            warn=warn,
            interrupt=interrupt,
            risk_streak=state.risk_streak,
        )
        score.validate()

        if commit:
            state.window.append(rec.update)
        return score

    def score_many(self, records: Iterable[TraceRecord]) -> Iterable[ScoreRecord]:
        for rec in records:
            yield self.score_one(rec)
