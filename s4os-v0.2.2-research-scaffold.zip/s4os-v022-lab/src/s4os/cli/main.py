# SPDX-License-Identifier: Apache-2.0
"""S4OS command line interface."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from s4os.core.config import RiskConfig, S4OSConfig
from s4os.data.schemas import load_scores, load_traces, save_scores, save_traces
from s4os.eval.reports import summarize_scores
from s4os.eval.synthetic import generate_synthetic_traces
from s4os.scoring.engine import ScoreEngine


def _config_from_args(args: argparse.Namespace) -> S4OSConfig:
    formula = getattr(args, "risk_formula", "product")
    return S4OSConfig(risk=RiskConfig(risk_formula=formula))


def cmd_synthetic(args: argparse.Namespace) -> int:
    records = list(
        generate_synthetic_traces(
            n_prompts=args.n_prompts,
            steps=args.steps,
            dim=args.dim,
            seed=args.seed,
            include_attractor=not args.no_attractor,
        )
    )
    n = save_traces(args.out, records)
    print(json.dumps({"wrote": n, "out": args.out, "include_attractor": not args.no_attractor}, indent=2))
    return 0


def cmd_score(args: argparse.Namespace) -> int:
    traces = load_traces(args.traces)
    engine = ScoreEngine(config=_config_from_args(args))
    scores = list(engine.score_many(traces))
    n = save_scores(args.out, scores)
    print(json.dumps({"scored": n, "out": args.out, "risk_formula": args.risk_formula}, indent=2))
    return 0


def cmd_report(args: argparse.Namespace) -> int:
    scores = load_scores(args.scores)
    report = summarize_scores(scores)
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps({"out": args.out, "n_records": report["n_records"]}, indent=2))
    return 0


def cmd_inspect(args: argparse.Namespace) -> int:
    scores = load_scores(args.scores)
    key = args.key
    rows = sorted(scores, key=lambda r: getattr(r, key) if getattr(r, key) is not None else -1, reverse=True)
    for r in rows[: args.top]:
        print(json.dumps(r.to_dict(), ensure_ascii=False, sort_keys=True))
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="s4os", description="S4OS v0.2.2 research scaffold CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("synthetic", help="Generate synthetic trace JSONL")
    p.add_argument("--out", required=True)
    p.add_argument("--n-prompts", type=int, default=20)
    p.add_argument("--steps", type=int, default=24)
    p.add_argument("--dim", type=int, default=64)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--no-attractor", action="store_true", help="omit condition-label attractor proxy")
    p.set_defaults(func=cmd_synthetic)

    p = sub.add_parser("score", help="Score trace JSONL")
    p.add_argument("--traces", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--risk-formula", choices=["product", "linear", "logistic"], default="product")
    p.set_defaults(func=cmd_score)

    p = sub.add_parser("report", help="Summarize score JSONL")
    p.add_argument("--scores", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_report)

    p = sub.add_parser("inspect", help="Print top score rows")
    p.add_argument("--scores", required=True)
    p.add_argument("--top", type=int, default=10)
    p.add_argument(
        "--key",
        default="full_risk",
        choices=[
            "full_risk",
            "geometric_risk",
            "geometric_product_risk",
            "geometric_linear_risk",
            "geometric_logistic_risk",
            "novelty",
            "margin_score",
            "collar_unit",
        ],
    )
    p.set_defaults(func=cmd_inspect)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
