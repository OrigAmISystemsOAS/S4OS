"""S4OS v0.2.2 research scaffold.

This package implements trace-level metrics and evaluation tooling for the
Directional Freezing hypothesis. It is not a production safety kernel.
"""

from s4os.core.config import MetricConfig, RiskConfig, S4OSConfig
from s4os.core.metrics import collar_persistence, normalized_margin, orthogonal_novelty
from s4os.core.risk import (
    compose_full_risk,
    compose_geometric_linear_risk,
    compose_geometric_logistic_risk,
    compose_geometric_product_risk,
)
from s4os.core.types import AttractorSource, ScoreRecord, TraceRecord
from s4os.scoring.engine import ScoreEngine

__version__ = "0.2.2"

__all__ = [
    "MetricConfig",
    "RiskConfig",
    "S4OSConfig",
    "TraceRecord",
    "ScoreRecord",
    "ScoreEngine",
    "AttractorSource",
    "orthogonal_novelty",
    "collar_persistence",
    "normalized_margin",
    "compose_geometric_product_risk",
    "compose_geometric_linear_risk",
    "compose_geometric_logistic_risk",
    "compose_full_risk",
]
