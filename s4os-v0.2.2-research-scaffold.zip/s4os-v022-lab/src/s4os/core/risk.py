# SPDX-License-Identifier: Apache-2.0
"""Risk composition functions.

Risk composition is treated as a calibrated screening statistic, not as a
first-principles detector. v0.2.2 exposes product, linear, and logistic geometric
baselines so experiments can report whether any particular composition is doing
useful work.
"""

from __future__ import annotations

import math

from s4os.core.metrics import clamp01
from s4os.core.types import RiskFormula


def compose_geometric_product_risk(
    *,
    novelty: float,
    collar_unit: float,
    margin_score: float,
    alpha_collar: float = 1.5,
    beta_low_novelty: float = 1.2,
    eta_margin: float = 0.8,
    energy_gate: bool = True,
) -> float:
    """Multiplicative geometric-risk baseline."""

    if not energy_gate:
        return 0.0
    risk = (
        clamp01(collar_unit) ** alpha_collar
        * (1.0 - clamp01(novelty)) ** beta_low_novelty
        * clamp01(margin_score) ** eta_margin
    )
    return clamp01(risk)


def compose_geometric_linear_risk(
    *,
    novelty: float,
    collar_unit: float,
    margin_score: float,
    w_collar: float = 1.0,
    w_low_novelty: float = 1.0,
    w_margin: float = 1.0,
    energy_gate: bool = True,
) -> float:
    """Additive geometric-risk baseline normalized by total positive weight."""

    if not energy_gate:
        return 0.0
    weights = [max(0.0, w_collar), max(0.0, w_low_novelty), max(0.0, w_margin)]
    denom = sum(weights)
    if denom <= 0:
        raise ValueError("At least one linear risk weight must be positive")
    score = (
        weights[0] * clamp01(collar_unit)
        + weights[1] * (1.0 - clamp01(novelty))
        + weights[2] * clamp01(margin_score)
    ) / denom
    return clamp01(score)


def compose_geometric_logistic_risk(
    *,
    novelty: float,
    collar_unit: float,
    margin_score: float,
    b0: float = -2.0,
    b_collar: float = 2.0,
    b_low_novelty: float = 2.0,
    b_margin: float = 1.0,
    energy_gate: bool = True,
) -> float:
    """Fixed-coefficient logistic geometric-risk baseline.

    This is not a trained model; it is a reproducible baseline. Learned variants
    should be reported separately with train/validation splits.
    """

    if not energy_gate:
        return 0.0
    z = (
        b0
        + b_collar * clamp01(collar_unit)
        + b_low_novelty * (1.0 - clamp01(novelty))
        + b_margin * clamp01(margin_score)
    )
    return clamp01(1.0 / (1.0 + math.exp(-z)))


def select_geometric_risk(
    *,
    formula: RiskFormula,
    product: float,
    linear: float,
    logistic: float,
) -> float:
    if formula == "product":
        return clamp01(product)
    if formula == "linear":
        return clamp01(linear)
    if formula == "logistic":
        return clamp01(logistic)
    raise ValueError(f"Unsupported risk formula: {formula}")


def compose_full_risk(
    *,
    geometric_risk: float,
    attractor_score: float | None,
    attractor_source: str = "none",
    gamma_attractor: float = 1.5,
) -> float | None:
    """Full risk; unavailable without independent attractor evidence."""

    if attractor_source == "none" or attractor_score is None:
        return None
    return clamp01(clamp01(geometric_risk) * clamp01(attractor_score) ** gamma_attractor)

# Backward-compatible aliases.
compose_geometric_risk = compose_geometric_product_risk
