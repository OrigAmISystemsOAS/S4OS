# SPDX-License-Identifier: Apache-2.0
"""Configuration objects for S4OS metrics and scoring."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

from s4os.core.types import RiskFormula


@dataclass(frozen=True)
class MetricConfig:
    """Numerical configuration for token-level metrics."""

    history_k: int = 5
    energy_eps: float = 1e-8
    top_k_margin: int = 50
    margin_sigmoid_a: float = 4.0
    margin_sigmoid_b: float = 1.0
    map_collar_to_unit_interval: bool = True

    def validate(self) -> None:
        if self.history_k < 1:
            raise ValueError("history_k must be >= 1")
        if self.energy_eps <= 0:
            raise ValueError("energy_eps must be > 0")
        if self.top_k_margin < 2:
            raise ValueError("top_k_margin must be >= 2")


@dataclass(frozen=True)
class RiskConfig:
    """Risk composition and streak thresholds.

    Full risk requires an independent attractor score. If no attractor score is
    available, only geometric baselines are reported and interrupts are disabled
    by default.
    """

    risk_formula: RiskFormula = "product"

    # Product baseline.
    alpha_collar: float = 1.5
    beta_low_novelty: float = 1.2
    eta_margin: float = 0.8

    # Linear baseline.
    w_collar: float = 1.0
    w_low_novelty: float = 1.0
    w_margin: float = 1.0

    # Logistic baseline.
    logistic_b0: float = -2.0
    logistic_b_collar: float = 2.0
    logistic_b_low_novelty: float = 2.0
    logistic_b_margin: float = 1.0

    # Attractor coupling.
    gamma_attractor: float = 1.5

    geometric_warn_threshold: float = 0.65
    full_warn_threshold: float = 0.55
    full_interrupt_threshold: float = 0.75
    min_interrupt_streak: int = 3
    allow_geometric_interrupt: bool = False

    def validate(self) -> None:
        if self.risk_formula not in ("product", "linear", "logistic"):
            raise ValueError("risk_formula must be product, linear, or logistic")
        for name in ("alpha_collar", "beta_low_novelty", "eta_margin", "gamma_attractor"):
            if getattr(self, name) <= 0:
                raise ValueError(f"{name} must be > 0")
        if self.w_collar < 0 or self.w_low_novelty < 0 or self.w_margin < 0:
            raise ValueError("linear risk weights must be >= 0")
        if self.w_collar + self.w_low_novelty + self.w_margin <= 0:
            raise ValueError("at least one linear risk weight must be positive")
        if self.min_interrupt_streak < 1:
            raise ValueError("min_interrupt_streak must be >= 1")
        for name in (
            "geometric_warn_threshold",
            "full_warn_threshold",
            "full_interrupt_threshold",
        ):
            val = getattr(self, name)
            if not 0 <= val <= 1:
                raise ValueError(f"{name} must lie in [0, 1]")


@dataclass(frozen=True)
class S4OSConfig:
    metric: MetricConfig = field(default_factory=MetricConfig)
    risk: RiskConfig = field(default_factory=RiskConfig)
    max_history: int = 256

    def validate(self) -> None:
        self.metric.validate()
        self.risk.validate()
        if self.max_history < self.metric.history_k:
            raise ValueError("max_history must be >= history_k")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
