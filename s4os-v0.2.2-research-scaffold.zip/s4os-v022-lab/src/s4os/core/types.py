# SPDX-License-Identifier: Apache-2.0
"""Typed trace and score records for S4OS v0.2.2.

The schema is deliberately explicit about two validity boundaries:

1. Attractor scores have a source. Full risk is valid only when the source is
   not ``none`` and the score lies in [0, 1]. Geometry must not be reused as a
   fake attractor estimate.
2. Update vectors have adapter semantics. A hidden-state difference is not the
   same claim as an exact residual pre/post hook.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Literal, get_args

TRACE_SCHEMA_VERSION = "s4os.trace.v2"
SCORE_SCHEMA_VERSION = "s4os.score.v2"

AttractorSource = Literal[
    "none",
    "condition_label",
    "human_label",
    "external_classifier",
    "trained_probe",
]

AdapterType = Literal[
    "synthetic",
    "hf_hidden_state_difference",
    "exact_residual_hook",
    "transformer_lens_hook",
    "state_space_delta",
    "black_box_surface",
    "unknown",
]

RiskFormula = Literal["product", "linear", "logistic"]


def _require_list_of_numbers(name: str, values: list[float | int]) -> None:
    if not isinstance(values, list):
        raise TypeError(f"{name} must be a list")
    if not values:
        raise ValueError(f"{name} must not be empty")
    for x in values:
        if not isinstance(x, (float, int)):
            raise TypeError(f"{name} must contain only numbers")


def _require_unit_interval(name: str, value: float | None) -> None:
    if value is None:
        return
    if not 0.0 <= float(value) <= 1.0:
        raise ValueError(f"{name} must lie in [0, 1] or be None")


@dataclass(frozen=True)
class TraceRecord:
    """One token-step update trace.

    ``update`` is an adapter-defined vector. The record stores the adapter type
    and semantics so that downstream reports do not silently conflate exact
    residual hooks, hidden-state differences, and synthetic vectors.
    """

    run_id: str
    prompt_id: str
    model_id: str
    step: int
    update: list[float]
    top_logit_values: list[float]
    top_logit_ids: list[int] = field(default_factory=list)
    token_id: int | None = None
    token_text: str | None = None
    condition: str | None = None
    label: int | None = None
    adapter_type: AdapterType = "unknown"
    adapter_semantics: str = "unspecified_update_vector"
    attractor_source: AttractorSource = "none"
    attractor_score: float | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: Literal["s4os.trace.v2"] = TRACE_SCHEMA_VERSION

    def validate(self) -> None:
        if self.schema_version != TRACE_SCHEMA_VERSION:
            raise ValueError(f"Unsupported trace schema: {self.schema_version}")
        if not self.run_id:
            raise ValueError("run_id must not be empty")
        if not self.prompt_id:
            raise ValueError("prompt_id must not be empty")
        if not self.model_id:
            raise ValueError("model_id must not be empty")
        if self.step < 0:
            raise ValueError("step must be >= 0")
        _require_list_of_numbers("update", self.update)
        _require_list_of_numbers("top_logit_values", self.top_logit_values)
        if len(self.top_logit_values) < 2:
            raise ValueError("top_logit_values must contain at least 2 logits")
        if self.top_logit_ids and len(self.top_logit_ids) != len(self.top_logit_values):
            raise ValueError("top_logit_ids must match top_logit_values length")
        if self.label is not None and self.label not in (0, 1):
            raise ValueError("label must be 0, 1, or None")
        if self.adapter_type not in get_args(AdapterType):
            raise ValueError(f"Unsupported adapter_type: {self.adapter_type}")
        if not self.adapter_semantics:
            raise ValueError("adapter_semantics must not be empty")
        if self.attractor_source not in get_args(AttractorSource):
            raise ValueError(f"Unsupported attractor_source: {self.attractor_source}")
        _require_unit_interval("attractor_score", self.attractor_score)
        if self.attractor_source == "none" and self.attractor_score is not None:
            raise ValueError("attractor_score requires attractor_source != 'none'")
        if self.attractor_source != "none" and self.attractor_score is None:
            raise ValueError("attractor_source != 'none' requires attractor_score")

    def to_dict(self) -> dict[str, Any]:
        self.validate()
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "TraceRecord":
        # v1 compatibility: migrate legacy metadata attractor_score if present.
        payload = dict(data)
        if payload.get("schema_version") == "s4os.trace.v1":
            payload["schema_version"] = TRACE_SCHEMA_VERSION
            meta = payload.get("metadata") or {}
            if payload.get("attractor_score") is None and "attractor_score" in meta:
                payload["attractor_score"] = meta["attractor_score"]
                payload["attractor_source"] = meta.get("attractor_source", "condition_label")
            payload.setdefault("adapter_type", meta.get("adapter", "unknown"))
            payload.setdefault("adapter_semantics", meta.get("adapter_semantics", "legacy_update_vector"))
        rec = cls(**payload)
        rec.validate()
        return rec

    @property
    def has_valid_attractor(self) -> bool:
        return self.attractor_source != "none" and self.attractor_score is not None


@dataclass(frozen=True)
class ScoreRecord:
    """Computed S4OS metrics for one trace step."""

    run_id: str
    prompt_id: str
    model_id: str
    step: int
    condition: str | None
    label: int | None
    adapter_type: AdapterType
    adapter_semantics: str
    attractor_source: AttractorSource
    novelty: float
    collar_raw: float
    collar_unit: float
    margin_score: float
    margin_z: float
    entropy_topk: float
    low_energy_fault: bool
    attractor_score: float | None
    geometric_product_risk: float
    geometric_linear_risk: float
    geometric_logistic_risk: float
    geometric_risk: float
    risk_formula: RiskFormula
    full_risk: float | None
    warn: bool
    interrupt: bool
    risk_streak: int
    schema_version: Literal["s4os.score.v2"] = SCORE_SCHEMA_VERSION

    def validate(self) -> None:
        if self.schema_version != SCORE_SCHEMA_VERSION:
            raise ValueError(f"Unsupported score schema: {self.schema_version}")
        if self.step < 0:
            raise ValueError("step must be >= 0")
        for name in (
            "novelty",
            "collar_unit",
            "margin_score",
            "geometric_product_risk",
            "geometric_linear_risk",
            "geometric_logistic_risk",
            "geometric_risk",
        ):
            val = getattr(self, name)
            if not 0.0 <= val <= 1.0:
                raise ValueError(f"{name} must lie in [0, 1]")
        if self.entropy_topk < 0:
            raise ValueError("entropy_topk must be >= 0")
        _require_unit_interval("attractor_score", self.attractor_score)
        if self.attractor_source == "none" and self.attractor_score is not None:
            raise ValueError("attractor_score requires attractor_source != 'none'")
        if self.full_risk is not None and not 0.0 <= self.full_risk <= 1.0:
            raise ValueError("full_risk must lie in [0, 1] or None")
        if self.attractor_source == "none" and self.full_risk is not None:
            raise ValueError("full_risk must be None when attractor_source == 'none'")
        if self.risk_formula not in get_args(RiskFormula):
            raise ValueError(f"Unsupported risk_formula: {self.risk_formula}")
        if self.risk_streak < 0:
            raise ValueError("risk_streak must be >= 0")
        if not self.adapter_semantics:
            raise ValueError("adapter_semantics must not be empty")

    def to_dict(self) -> dict[str, Any]:
        self.validate()
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ScoreRecord":
        payload = dict(data)
        if payload.get("schema_version") == "s4os.score.v1":
            payload["schema_version"] = SCORE_SCHEMA_VERSION
            payload.setdefault("adapter_type", "unknown")
            payload.setdefault("adapter_semantics", "legacy_update_vector")
            payload.setdefault("attractor_source", "condition_label" if payload.get("attractor_score") is not None else "none")
            old_geo = float(payload.get("geometric_risk", 0.0))
            payload.setdefault("geometric_product_risk", old_geo)
            payload.setdefault("geometric_linear_risk", old_geo)
            payload.setdefault("geometric_logistic_risk", old_geo)
            payload.setdefault("risk_formula", "product")
        rec = cls(**payload)
        rec.validate()
        return rec
