# Contributing

Contributions are welcome, especially:

- model adapters for exact residual pre/post hooks,
- labeled sycophancy/healthy-agreement datasets,
- U1 calibration notebooks,
- ablation studies,
- benchmark harnesses,
- safety and reliability reviews.

Please keep claims scoped. Do not add documentation claiming universal detection unless validated.
