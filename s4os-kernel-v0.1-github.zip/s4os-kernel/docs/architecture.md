# S⁴OS Architecture

## Boundary discipline

S⁴OS v0.1 separates four levels:

1. **Tensor metrics**: computable quantities over hidden/residual-like states.
2. **Behavioral labels**: sycophancy / healthy agreement / correction.
3. **Runtime policy**: interrupt and recovery decisions.
4. **Surface realization**: text-level repair that remains coherent.

Moving between these levels requires validation. The package does not equate them by definition.

## Tensor path

Given hidden states from an open Transformer model:

```text
hidden_states[0]      embedding output
hidden_states[l]      layer output
hidden_states[l + 1]  next layer output
```

The generic update approximation is:

```text
Δr_l,t = hidden_states[l + 1][:, t, :] - hidden_states[l][:, t, :]
```

This is then projected:

```text
v_l,t = P_l^U1 W_l Δr_l,t
v_t = Σ_l α_l v_l,t
```

Where `P_l^U1`, `W_l`, and `α_l` should be calibrated.

## Metrics

### Orthogonal Novelty

```text
N_t = ||v_t - Proj_span(v_{t-k:t-1}) v_t|| / (||v_t|| + ε)
```

### Collar Persistence

```text
C_t = mean_i cos(v_t, v_{t-i})
```

Mapped to `[0, 1]` for risk calculation.

### Margin

```text
m_t = (z_top1 - z_top2) / std(z_topK)
M_t = sigmoid(a(m_t - b))
```

### Attractor

```text
A_t = f_probe(features_t)
```

The probe should be trained to detect *unearned agreement*, not agreement itself.

### Risk

```text
R_t = C_t^α (1 - N_t)^β A_t^γ M_t^η
```

## Recovery

Recovery is not a visible restart. It is a pre-commit decision:

1. block candidate commit,
2. generate/score branches,
3. pick coherent low-risk branch,
4. surface repair only if branch recovery fails.

## Falsifiers

The approach is weakened if:

- novelty/collar do not separate sycophancy from healthy high-confidence answers,
- attractor probe merely detects politeness or agreement,
- reranking reduces factual accuracy,
- false positive rate is too high on math/facts,
- recovery increases verbosity without improving calibration.
