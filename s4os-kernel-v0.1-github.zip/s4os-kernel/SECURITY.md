# Security and Safety

S⁴OS is an experimental monitoring and reranking suite. It should not be used as the sole safety mechanism for deployed high-stakes systems.

Report vulnerabilities or harmful failure modes through your project's normal security channel.
