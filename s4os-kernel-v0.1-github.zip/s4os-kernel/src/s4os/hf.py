"""Hugging Face causal-LM integration.

This module is intentionally optional. It uses model outputs with
`output_hidden_states=True` and approximates per-layer residual updates as
hidden_states[l+1] - hidden_states[l] at the current token position.

For architecture-specific exact pre/post residual hooks, implement a custom
adapter instead of relying on this generic runner.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Sequence

from ._optional import require_torch, require_transformers
from .monitor import S4OSMonitor, S4OSSnapshot
from .probes import HeuristicAttractorProbe, ProbeFeatures


@dataclass
class HFGenerationResult:
    text: str
    token_ids: list[int]
    snapshots: list[S4OSSnapshot] = field(default_factory=list)
    interrupted: bool = False
    recovery_events: list[dict[str, Any]] = field(default_factory=list)


class HFStepRunner:
    """Stepwise monitored generation for Hugging Face causal LMs."""

    def __init__(
        self,
        model,
        tokenizer,
        monitor: S4OSMonitor,
        layers: Sequence[int] | None = None,
        layer_weights: Sequence[float] | None = None,
        attractor_probe: Any | None = None,
        device: str | None = None,
    ):
        require_transformers()
        torch = require_torch()

        self.model = model
        self.tokenizer = tokenizer
        self.monitor = monitor
        self.layers = list(layers) if layers is not None else [-4, -3, -2]
        self.attractor_probe = attractor_probe or HeuristicAttractorProbe()

        self.device = device or next(model.parameters()).device
        self.model.to(self.device)
        self.model.eval()

        if layer_weights is None:
            self.layer_weights = [1.0 / len(self.layers)] * len(self.layers)
        else:
            if len(layer_weights) != len(self.layers):
                raise ValueError("layer_weights must match layers length.")
            total = float(sum(layer_weights))
            if total <= 0:
                raise ValueError("layer_weights must sum to positive value.")
            self.layer_weights = [float(w) / total for w in layer_weights]

        self.torch = torch

    def _resolve_layer_index(self, idx: int, n_hidden_states: int) -> int:
        # hidden_states contains embeddings plus layer outputs.
        if idx < 0:
            idx = n_hidden_states + idx - 1
        if idx < 0 or idx + 1 >= n_hidden_states:
            raise IndexError(
                f"Layer index {idx} invalid for {n_hidden_states} hidden-state tensors. "
                "Remember hidden_states includes embeddings at index 0."
            )
        return idx

    def extract_delta(self, hidden_states, position: int = -1):
        """Aggregate hidden-state differences over configured layers."""

        torch = self.torch
        n = len(hidden_states)
        deltas = []

        for layer_idx, weight in zip(self.layers, self.layer_weights):
            j = self._resolve_layer_index(layer_idx, n)
            pre = hidden_states[j][:, position, :]
            post = hidden_states[j + 1][:, position, :]
            deltas.append(float(weight) * (post - pre))

        return torch.stack(deltas, dim=0).sum(dim=0).squeeze(0)

    def _select_token(self, logits, do_sample: bool = False, temperature: float = 1.0):
        torch = self.torch
        if do_sample:
            probs = torch.softmax(logits / max(temperature, 1e-6), dim=-1)
            return torch.multinomial(probs, num_samples=1)
        return torch.argmax(logits, dim=-1, keepdim=True)

    def _score_attractor(self, novelty: float, collar: float, margin: float, user_pressure: float) -> float:
        if isinstance(self.attractor_probe, HeuristicAttractorProbe):
            return self.attractor_probe.score(
                ProbeFeatures(
                    novelty=novelty,
                    collar=collar,
                    margin=margin,
                    user_pressure=user_pressure,
                )
            )
        return 0.0

    def generate_monitored(
        self,
        prompt: str,
        max_new_tokens: int = 64,
        do_sample: bool = False,
        temperature: float = 1.0,
        user_pressure: float = 0.0,
        surface_repair_text: str = " More precisely, the robust formulation is: ",
    ) -> HFGenerationResult:
        """Generate text while monitoring pre-commit token decisions.

        On interrupt, v0.1 performs a conservative surface repair by injecting a
        short repair phrase once. Full residual steering is intentionally not
        implemented generically because it is architecture-specific.
        """

        torch = self.torch
        enc = self.tokenizer(prompt, return_tensors="pt")
        input_ids = enc["input_ids"].to(self.device)
        attention_mask = enc.get("attention_mask")
        if attention_mask is not None:
            attention_mask = attention_mask.to(self.device)

        generated: list[int] = []
        snapshots: list[S4OSSnapshot] = []
        recovery_events: list[dict[str, Any]] = []
        interrupted = False
        repair_used = False

        with torch.no_grad():
            outputs = self.model(
                input_ids=input_ids,
                attention_mask=attention_mask,
                use_cache=True,
                output_hidden_states=True,
                return_dict=True,
            )

            past = outputs.past_key_values
            logits = outputs.logits[:, -1, :]

            for step_idx in range(max_new_tokens):
                delta_r = self.extract_delta(outputs.hidden_states, position=-1)

                # First pass with neutral attractor to get novelty/collar/margin;
                # then heuristic probe can be computed and step repeated without committing.
                preview, _ = self.monitor.evaluate(delta_r, logits.squeeze(0), attractor_score=0.0)
                attractor = self._score_attractor(
                    novelty=preview.novelty,
                    collar=preview.collar,
                    margin=preview.margin,
                    user_pressure=user_pressure,
                )
                snap = self.monitor.step(delta_r, logits.squeeze(0), attractor_score=attractor)
                snapshots.append(snap)

                if snap.interrupt and not repair_used:
                    interrupted = True
                    repair_used = True
                    recovery_events.append(
                        {
                            "step": step_idx,
                            "risk": snap.collapse_risk,
                            "action": "surface_repair_injection",
                        }
                    )
                    repair_ids = self.tokenizer(surface_repair_text, return_tensors="pt")["input_ids"].to(
                        self.device
                    )[0].tolist()
                    generated.extend(repair_ids)
                    # Feed repair ids to update model state.
                    repair_tensor = torch.tensor([repair_ids], device=self.device)
                    outputs = self.model(
                        input_ids=repair_tensor,
                        past_key_values=past,
                        use_cache=True,
                        output_hidden_states=True,
                        return_dict=True,
                    )
                    past = outputs.past_key_values
                    logits = outputs.logits[:, -1, :]
                    continue

                next_token = self._select_token(logits, do_sample=do_sample, temperature=temperature)
                token_id = int(next_token.squeeze().item())
                generated.append(token_id)

                if self.tokenizer.eos_token_id is not None and token_id == self.tokenizer.eos_token_id:
                    break

                outputs = self.model(
                    input_ids=next_token.reshape(1, 1),
                    past_key_values=past,
                    use_cache=True,
                    output_hidden_states=True,
                    return_dict=True,
                )
                past = outputs.past_key_values
                logits = outputs.logits[:, -1, :]

        text = self.tokenizer.decode(generated, skip_special_tokens=True)
        return HFGenerationResult(
            text=text,
            token_ids=generated,
            snapshots=snapshots,
            interrupted=interrupted,
            recovery_events=recovery_events,
        )
