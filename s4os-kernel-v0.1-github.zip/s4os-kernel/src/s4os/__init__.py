"""S⁴OS Kernel.

Experimental semantic-stability monitoring and recovery-reranking utilities.

The package intentionally separates:
- tensor mode: open models with hidden-state access,
- surface mode: closed/chat models without residual hooks.
"""

from .config import RiskWeights, S4OSConfig, S4OSThresholds
from .monitor import S4OSMonitor, S4OSSnapshot
from .projection import U1Projector
from .surface import SurfaceDecision, SurfaceS4OSKernel

__all__ = [
    "RiskWeights",
    "S4OSConfig",
    "S4OSThresholds",
    "S4OSMonitor",
    "S4OSSnapshot",
    "U1Projector",
    "SurfaceDecision",
    "SurfaceS4OSKernel",
]
