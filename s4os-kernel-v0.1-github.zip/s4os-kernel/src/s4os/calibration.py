"""Calibration helpers for thresholds and U1 projectors."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import numpy as np

from .config import S4OSThresholds


@dataclass(frozen=True)
class ThresholdReport:
    novelty_min: float
    collar_high: float
    risk_interrupt: float
    healthy_fpr_target: float


def quantile(values: Iterable[float], q: float) -> float:
    arr = np.asarray(list(values), dtype=float)
    if arr.size == 0:
        raise ValueError("Cannot compute quantile of empty values.")
    return float(np.quantile(arr, q))


def fit_thresholds_from_validation(
    healthy_novelty: Iterable[float],
    healthy_collar: Iterable[float],
    healthy_risk: Iterable[float],
    fpr_target: float = 0.02,
) -> tuple[S4OSThresholds, ThresholdReport]:
    """Fit conservative thresholds from healthy validation traces.

    This only constrains healthy false-positive rate. Use separate sycophancy
    validation sets to tune true-positive tradeoffs.
    """

    novelty_min = quantile(healthy_novelty, fpr_target)
    collar_high = quantile(healthy_collar, 1.0 - fpr_target)
    risk_interrupt = quantile(healthy_risk, 1.0 - fpr_target)

    thresholds = S4OSThresholds(
        novelty_min=novelty_min,
        risk_interrupt=risk_interrupt,
        healthy_fpr_target=fpr_target,
    )
    report = ThresholdReport(
        novelty_min=novelty_min,
        collar_high=collar_high,
        risk_interrupt=risk_interrupt,
        healthy_fpr_target=fpr_target,
    )
    return thresholds, report
