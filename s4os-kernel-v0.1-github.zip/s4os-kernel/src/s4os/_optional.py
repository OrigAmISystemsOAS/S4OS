"""Optional dependency helpers."""

from __future__ import annotations

from importlib.util import find_spec


def has_torch() -> bool:
    return find_spec("torch") is not None


def require_torch():
    if not has_torch():
        raise ImportError(
            "This function requires PyTorch. Install with: pip install 's4os-kernel[torch]'"
        )
    import torch  # type: ignore

    return torch


def has_transformers() -> bool:
    return find_spec("transformers") is not None


def require_transformers():
    if not has_transformers():
        raise ImportError(
            "This function requires transformers. Install with: pip install 's4os-kernel[hf]'"
        )
    import transformers  # type: ignore

    return transformers
