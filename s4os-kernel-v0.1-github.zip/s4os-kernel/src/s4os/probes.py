"""Agreement/attractor probe models."""

from __future__ import annotations

from dataclasses import dataclass

from ._optional import require_torch
from .metrics import clamp01


@dataclass(frozen=True)
class ProbeFeatures:
    novelty: float
    collar: float
    margin: float
    entropy_delta: float = 0.0
    user_pressure: float = 0.0


class HeuristicAttractorProbe:
    """Deterministic fallback probe.

    This is not a trained classifier. It is useful for demos and as a baseline.
    """

    def __init__(
        self,
        w_collar: float = 1.0,
        w_low_novelty: float = 1.0,
        w_margin: float = 0.6,
        w_user_pressure: float = 0.8,
        bias: float = -1.6,
    ):
        self.w_collar = w_collar
        self.w_low_novelty = w_low_novelty
        self.w_margin = w_margin
        self.w_user_pressure = w_user_pressure
        self.bias = bias

    def score(self, features: ProbeFeatures) -> float:
        import math

        z = (
            self.bias
            + self.w_collar * features.collar
            + self.w_low_novelty * (1.0 - features.novelty)
            + self.w_margin * features.margin
            + self.w_user_pressure * features.user_pressure
        )
        return clamp01(1.0 / (1.0 + math.exp(-z)))


class AttractorProbe:
    """Tiny PyTorch MLP for agreement-attractor probability.

    Inputs should be calibrated features; the class does not prescribe labels.
    """

    def __init__(self, input_dim: int, hidden_dim: int = 128):
        torch = require_torch()
        nn = torch.nn

        class _Probe(nn.Module):
            def __init__(self, input_dim: int, hidden_dim: int):
                super().__init__()
                self.net = nn.Sequential(
                    nn.Linear(input_dim, hidden_dim),
                    nn.GELU(),
                    nn.Linear(hidden_dim, 1),
                )

            def forward(self, x):
                return torch.sigmoid(self.net(x)).squeeze(-1)

        self.model = _Probe(input_dim=input_dim, hidden_dim=hidden_dim)

    def __call__(self, features):
        return self.model(features)

    def save(self, path: str) -> None:
        torch = require_torch()
        torch.save(self.model.state_dict(), path)

    def load(self, path: str) -> None:
        torch = require_torch()
        self.model.load_state_dict(torch.load(path, map_location="cpu"))
