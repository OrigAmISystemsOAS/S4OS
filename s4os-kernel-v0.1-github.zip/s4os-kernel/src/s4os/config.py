"""Configuration dataclasses for S⁴OS."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(frozen=True)
class RiskWeights:
    """Exponents in the semantic collapse risk product.

    risk = collar^alpha * (1 - novelty)^beta * attractor^gamma * margin^eta
    """

    alpha: float = 1.5
    beta: float = 1.2
    gamma: float = 1.5
    eta: float = 0.8


@dataclass(frozen=True)
class S4OSThresholds:
    """Operational thresholds.

    These defaults are conservative placeholders. They must be calibrated on a
    validation set for any real deployment.
    """

    energy_eps: float = 1e-8
    risk_warn: float = 0.45
    risk_interrupt: float = 0.75
    min_interrupt_streak: int = 3

    novelty_min: float = 0.06
    novelty_max: float = 0.95

    coherence_min: float = 0.25
    drift_max: float = 0.60
    leap_max: float = 0.55

    healthy_fpr_target: float = 0.02


@dataclass(frozen=True)
class RerankWeights:
    """Linear weights used by the recovery reranker."""

    logprob: float = 1.0
    risk: float = 2.5
    novelty: float = 0.6
    coherence: float = 1.2
    bridge: float = 0.8
    drift: float = 1.2
    leap: float = 1.5


@dataclass(frozen=True)
class S4OSConfig:
    """Top-level S⁴OS config."""

    history_k: int = 5
    max_history: int = 128
    top_k_margin: int = 50
    thresholds: S4OSThresholds = field(default_factory=S4OSThresholds)
    risk_weights: RiskWeights = field(default_factory=RiskWeights)
    rerank_weights: RerankWeights = field(default_factory=RerankWeights)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "S4OSConfig":
        thresholds = S4OSThresholds(**data.get("thresholds", {}))
        risk_weights = RiskWeights(**data.get("risk_weights", {}))
        rerank_weights = RerankWeights(**data.get("rerank_weights", {}))
        payload = dict(data)
        payload.pop("thresholds", None)
        payload.pop("risk_weights", None)
        payload.pop("rerank_weights", None)
        return cls(
            **payload,
            thresholds=thresholds,
            risk_weights=risk_weights,
            rerank_weights=rerank_weights,
        )
