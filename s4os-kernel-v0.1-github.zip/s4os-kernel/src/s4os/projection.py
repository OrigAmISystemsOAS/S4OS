"""U1 projection utilities."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ._optional import require_torch


@dataclass
class U1Projector:
    """Projection into a calibrated U1/tension subspace.

    `components` has shape [input_dim, subspace_dim].
    If `components` is None, identity projection is used.
    """

    components: Any | None = None
    mean: Any | None = None
    scale: Any | None = None
    name: str = "u1"

    @classmethod
    def identity(cls, dim: int, name: str = "identity") -> "U1Projector":
        torch = require_torch()
        return cls(components=torch.eye(dim), name=name)

    @classmethod
    def from_pca(
        cls,
        samples,
        subspace_dim: int,
        center: bool = True,
        whiten: bool = False,
        name: str = "pca-u1",
    ) -> "U1Projector":
        """Fit a PCA projector from sample vectors.

        This is a generic helper. For real U1, fit samples from labeled contrastive
        trajectories, not arbitrary activations.
        """

        torch = require_torch()

        if samples.ndim != 2:
            raise ValueError("samples must have shape [n_samples, input_dim].")
        if subspace_dim <= 0 or subspace_dim > samples.shape[1]:
            raise ValueError("subspace_dim must be in [1, input_dim].")

        mean = samples.mean(dim=0) if center else torch.zeros(samples.shape[1], device=samples.device)
        X = samples - mean

        # SVD gives right singular vectors as Vh; components are columns.
        _, S, Vh = torch.linalg.svd(X, full_matrices=False)
        components = Vh[:subspace_dim].T.contiguous()

        scale = None
        if whiten:
            scale_vec = S[:subspace_dim] / max(1, samples.shape[0] - 1) ** 0.5
            scale = torch.clamp(scale_vec, min=1e-8)

        return cls(components=components, mean=mean, scale=scale, name=name)

    @property
    def input_dim(self) -> int | None:
        if self.components is None:
            return None
        return int(self.components.shape[0])

    @property
    def output_dim(self) -> int | None:
        if self.components is None:
            return None
        return int(self.components.shape[1])

    def project(self, x):
        torch = require_torch()

        v = x.flatten()
        if self.components is None:
            return v

        comp = self.components.to(device=v.device, dtype=v.dtype)
        if comp.shape[0] != v.numel():
            raise ValueError(
                f"Projector input_dim={comp.shape[0]} does not match vector dim={v.numel()}."
            )

        if self.mean is not None:
            mean = self.mean.to(device=v.device, dtype=v.dtype)
            v = v - mean

        y = v @ comp

        if self.scale is not None:
            scale = self.scale.to(device=v.device, dtype=v.dtype)
            y = y / torch.clamp(scale, min=1e-8)

        return y

    def save(self, path: str | Path) -> None:
        torch = require_torch()
        payload = {
            "components": self.components,
            "mean": self.mean,
            "scale": self.scale,
            "name": self.name,
        }
        torch.save(payload, Path(path))

    @classmethod
    def load(cls, path: str | Path) -> "U1Projector":
        torch = require_torch()
        payload = torch.load(Path(path), map_location="cpu")
        return cls(**payload)
