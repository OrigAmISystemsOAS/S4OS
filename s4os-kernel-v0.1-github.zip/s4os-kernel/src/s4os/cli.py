"""Command-line interfaces."""

from __future__ import annotations

import argparse
import json
import sys

from .surface import SurfaceS4OSKernel


def surface_check_main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Surface-level S4OS risk check.")
    parser.add_argument("--text", required=True, help="Text to evaluate.")
    parser.add_argument("--language", default="en", help="Recovery language: en or de.")
    args = parser.parse_args(argv)

    kernel = SurfaceS4OSKernel()
    decision = kernel.evaluate(args.text)
    recovered = kernel.recover(args.text, language=args.language) if decision.recovery_needed else args.text

    print(
        json.dumps(
            {
                "risk": decision.risk,
                "claim_strength": decision.claim_strength,
                "bridge_score": decision.bridge_score,
                "overaffirmation": decision.overaffirmation,
                "recovery_needed": decision.recovery_needed,
                "recovery_hint": decision.recovery_hint,
                "recovered": recovered,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


def trace_score_main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Score precomputed JSONL traces. Each line should contain "
            "{'novelty', 'collar', 'margin', 'attractor'} or raw vectors are not yet supported."
        )
    )
    parser.add_argument("--input", required=True, help="JSONL file.")
    args = parser.parse_args(argv)

    from .config import RiskWeights
    from .metrics import semantic_risk

    weights = RiskWeights()
    with open(args.input, "r", encoding="utf-8") as f:
        for line in f:
            obj = json.loads(line)
            risk = semantic_risk(
                collar=float(obj["collar"]),
                novelty=float(obj["novelty"]),
                attractor=float(obj["attractor"]),
                margin=float(obj["margin"]),
                alpha=weights.alpha,
                beta=weights.beta,
                gamma=weights.gamma,
                eta=weights.eta,
            )
            obj["collapse_risk"] = risk
            print(json.dumps(obj, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(surface_check_main(sys.argv[1:]))
