"""Tensor metrics for S⁴OS.

The functions here are intentionally low-level and side-effect free.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

from ._optional import require_torch


@dataclass(frozen=True)
class MetricValues:
    novelty: float
    collar: float
    margin: float
    raw_margin: float
    entropy: float
    low_energy_fault: bool


def clamp01(x: float) -> float:
    return max(0.0, min(1.0, float(x)))


def cosine(a, b, eps: float = 1e-8) -> float:
    torch = require_torch()
    denom = (torch.linalg.vector_norm(a) * torch.linalg.vector_norm(b)) + eps
    return float(torch.dot(a.flatten(), b.flatten()) / denom)


def orthogonal_novelty(v_t, history: Sequence, k: int = 5, eps: float = 1e-8) -> tuple[float, bool]:
    """Return normalized orthogonal novelty.

    N_t = ||v_t - Proj_span(history) v_t|| / (||v_t|| + eps)

    Returns:
        (novelty, low_energy_fault)
    """

    torch = require_torch()

    norm = torch.linalg.vector_norm(v_t)
    if float(norm) < eps:
        return 0.0, True

    recent = list(history)[-k:]
    if len(recent) < 2:
        return 1.0, False

    B = torch.stack([x.detach().flatten() for x in recent], dim=1)  # q x k
    v = v_t.flatten()

    # QR-based projection is numerically safer than direct inverse.
    try:
        Q, _ = torch.linalg.qr(B, mode="reduced")
        proj = Q @ (Q.T @ v)
    except RuntimeError:
        # Fallback for rank-deficient / backend-specific QR failures.
        coeffs = torch.linalg.lstsq(B, v).solution
        proj = B @ coeffs

    residual = v - proj
    novelty = torch.linalg.vector_norm(residual) / (norm + eps)
    return clamp01(float(novelty)), False


def collar_persistence(v_t, history: Sequence, k: int = 5, eps: float = 1e-8) -> float:
    """Mean cosine similarity to recent U1 updates."""

    torch = require_torch()

    recent = list(history)[-k:]
    if not recent:
        return 0.0

    v = v_t.flatten()
    vals = []
    for u in recent:
        u_flat = u.detach().flatten()
        denom = torch.linalg.vector_norm(v) * torch.linalg.vector_norm(u_flat) + eps
        vals.append(float(torch.dot(v, u_flat) / denom))

    # Map from [-1, 1] to [0, 1] because risk formulas expect non-negative factors.
    # A negative counter-direction is anti-freezing, not risky.
    mean_cos = sum(vals) / len(vals)
    return clamp01((mean_cos + 1.0) / 2.0)


def normalized_margin(logits, top_k: int = 50, a: float = 4.0, b: float = 1.0, eps: float = 1e-8) -> tuple[float, float]:
    """Return sigmoid-normalized top1-top2 margin and raw normalized margin."""

    torch = require_torch()

    logits = logits.flatten()
    k = min(top_k, logits.numel())
    if k < 2:
        raise ValueError("Need at least two logits to compute margin.")

    top_values = torch.topk(logits, k=k).values
    raw = top_values[0] - top_values[1]
    scale = top_values.std(unbiased=False) + eps
    z = raw / scale
    score = torch.sigmoid(torch.as_tensor(a, device=logits.device) * (z - b))
    return clamp01(float(score)), float(z)


def entropy_from_logits(logits, eps: float = 1e-12) -> float:
    """Shannon entropy of the next-token distribution."""

    torch = require_torch()

    p = torch.softmax(logits.flatten(), dim=-1)
    h = -(p * torch.log(p + eps)).sum()
    return float(h)


def semantic_risk(
    collar: float,
    novelty: float,
    attractor: float,
    margin: float,
    alpha: float = 1.5,
    beta: float = 1.2,
    gamma: float = 1.5,
    eta: float = 0.8,
    energy_gate: bool = True,
) -> float:
    """Multi-signal semantic collapse risk.

    No individual component is sufficient for an interrupt.
    """

    if not energy_gate:
        return 0.0

    risk = (
        clamp01(collar) ** alpha
        * (1.0 - clamp01(novelty)) ** beta
        * clamp01(attractor) ** gamma
        * clamp01(margin) ** eta
    )
    return clamp01(risk)
