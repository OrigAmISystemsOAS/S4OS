"""Recovery reranking."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable

from .config import RerankWeights, S4OSThresholds


@dataclass(frozen=True)
class CandidateMetrics:
    logprob: float = 0.0
    risk: float = 0.0
    novelty: float = 0.5
    coherence: float = 0.5
    bridge: float = 0.0
    drift: float = 0.0
    leap: float = 0.0


@dataclass(frozen=True)
class Candidate:
    text: str
    metrics: CandidateMetrics
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class RerankResult:
    candidate: Candidate | None
    score: float | None
    valid_candidates: list[tuple[Candidate, float]]
    rejected: list[tuple[Candidate, str]]


class RecoveryReranker:
    """Selects a coherent low-risk continuation.

    The reranker is deliberately conservative: candidates must pass hard gates
    before they are scored.
    """

    def __init__(
        self,
        thresholds: S4OSThresholds | None = None,
        weights: RerankWeights | None = None,
    ):
        self.thresholds = thresholds or S4OSThresholds()
        self.weights = weights or RerankWeights()

    def rejection_reason(self, c: Candidate) -> str | None:
        m = c.metrics
        if m.risk >= self.thresholds.risk_interrupt:
            return "risk"
        if not (self.thresholds.novelty_min < m.novelty < self.thresholds.novelty_max):
            return "novelty"
        if m.coherence <= self.thresholds.coherence_min:
            return "coherence"
        if m.drift >= self.thresholds.drift_max:
            return "drift"
        if m.leap >= self.thresholds.leap_max:
            return "leap"
        return None

    def score(self, c: Candidate) -> float:
        m = c.metrics
        w = self.weights
        return (
            w.logprob * m.logprob
            - w.risk * m.risk
            + w.novelty * m.novelty
            + w.coherence * m.coherence
            + w.bridge * m.bridge
            - w.drift * m.drift
            - w.leap * m.leap
        )

    def select(self, candidates: Iterable[Candidate]) -> RerankResult:
        valid: list[tuple[Candidate, float]] = []
        rejected: list[tuple[Candidate, str]] = []

        for c in candidates:
            reason = self.rejection_reason(c)
            if reason is not None:
                rejected.append((c, reason))
                continue
            valid.append((c, self.score(c)))

        if not valid:
            return RerankResult(candidate=None, score=None, valid_candidates=[], rejected=rejected)

        best = max(valid, key=lambda pair: pair[1])
        return RerankResult(
            candidate=best[0],
            score=best[1],
            valid_candidates=valid,
            rejected=rejected,
        )


class SurfaceCandidateScorer:
    """Simple lexical scorer for surface-level recovery candidates.

    This is not a substitute for tensor scoring. It supports closed-model usage
    and testable demos.
    """

    bridge_terms = (
        "status",
        "hypothesis",
        "evidence",
        "bridge",
        "condition",
        "limitation",
        "scope",
        "operational",
        "calibrate",
        "validate",
        "falsifier",
        "not yet",
        "however",
        "but",
        "constraint",
        "architecture",
    )

    leap_terms = (
        "proves everything",
        "universal proof",
        "obviously conscious",
        "therefore AGI",
        "guaranteed",
        "no doubt",
        "without validation",
    )

    def score_text(self, text: str, logprob: float = 0.0, risk: float = 0.0) -> Candidate:
        t = text.lower()
        bridge = min(1.0, sum(term in t for term in self.bridge_terms) / 4.0)
        leap = min(1.0, sum(term in t for term in self.leap_terms) / 2.0)
        drift = 0.15 if any(term in t for term in self.bridge_terms) else 0.35
        coherence = 0.7 if len(text.strip()) > 0 else 0.0
        novelty = 0.55 + 0.20 * bridge - 0.15 * leap
        metrics = CandidateMetrics(
            logprob=logprob,
            risk=risk,
            novelty=max(0.0, min(1.0, novelty)),
            coherence=coherence,
            bridge=bridge,
            drift=drift,
            leap=leap,
        )
        return Candidate(text=text, metrics=metrics)
