"""Streaming S⁴OS monitor."""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import Deque

from .config import S4OSConfig
from .metrics import (
    collar_persistence,
    entropy_from_logits,
    normalized_margin,
    orthogonal_novelty,
    semantic_risk,
)
from .projection import U1Projector


@dataclass(frozen=True)
class S4OSSnapshot:
    """Metrics for one token/candidate step."""

    novelty: float
    collar: float
    margin: float
    raw_margin: float
    entropy: float
    attractor: float
    collapse_risk: float
    warn: bool
    interrupt: bool
    low_energy_fault: bool
    risk_streak: int


class S4OSMonitor:
    """Stateful streaming monitor.

    `step` evaluates one residual-update/logit pair and commits the projected U1
    vector to history by default.
    """

    def __init__(self, projector: U1Projector, config: S4OSConfig | None = None):
        self.projector = projector
        self.config = config or S4OSConfig()
        self.history: Deque = deque(maxlen=self.config.max_history)
        self.snapshots: list[S4OSSnapshot] = []
        self.risk_streak = 0

    def reset(self) -> None:
        self.history.clear()
        self.snapshots.clear()
        self.risk_streak = 0

    def clone_empty(self) -> "S4OSMonitor":
        return S4OSMonitor(projector=self.projector, config=self.config)

    def project(self, delta_r):
        return self.projector.project(delta_r)

    def evaluate(
        self,
        delta_r,
        logits,
        attractor_score: float = 0.0,
    ) -> tuple[S4OSSnapshot, object]:
        v_t = self.project(delta_r)

        novelty, low_energy_fault = orthogonal_novelty(
            v_t,
            list(self.history),
            k=self.config.history_k,
            eps=self.config.thresholds.energy_eps,
        )
        collar = collar_persistence(
            v_t,
            list(self.history),
            k=self.config.history_k,
            eps=self.config.thresholds.energy_eps,
        )
        margin, raw_margin = normalized_margin(
            logits,
            top_k=self.config.top_k_margin,
            eps=self.config.thresholds.energy_eps,
        )
        entropy = entropy_from_logits(logits)

        risk = semantic_risk(
            collar=collar,
            novelty=novelty,
            attractor=attractor_score,
            margin=margin,
            alpha=self.config.risk_weights.alpha,
            beta=self.config.risk_weights.beta,
            gamma=self.config.risk_weights.gamma,
            eta=self.config.risk_weights.eta,
            energy_gate=not low_energy_fault,
        )

        if risk > self.config.thresholds.risk_interrupt:
            next_streak = self.risk_streak + 1
        else:
            next_streak = 0

        snap = S4OSSnapshot(
            novelty=novelty,
            collar=collar,
            margin=margin,
            raw_margin=raw_margin,
            entropy=entropy,
            attractor=float(attractor_score),
            collapse_risk=risk,
            warn=risk > self.config.thresholds.risk_warn,
            interrupt=(
                next_streak >= self.config.thresholds.min_interrupt_streak
                and risk > self.config.thresholds.risk_interrupt
            ),
            low_energy_fault=low_energy_fault,
            risk_streak=next_streak,
        )
        return snap, v_t

    def commit_vector(self, v_t) -> None:
        self.history.append(v_t.detach())

    def commit_snapshot(self, snapshot: S4OSSnapshot) -> None:
        self.snapshots.append(snapshot)
        self.risk_streak = snapshot.risk_streak

    def step(self, delta_r, logits, attractor_score: float = 0.0, commit: bool = True) -> S4OSSnapshot:
        snapshot, v_t = self.evaluate(delta_r=delta_r, logits=logits, attractor_score=attractor_score)
        if commit:
            self.commit_vector(v_t)
            self.commit_snapshot(snapshot)
        return snapshot
