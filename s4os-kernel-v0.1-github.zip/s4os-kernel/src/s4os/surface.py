"""Surface-level S⁴OS kernel for closed/chat models.

This approximates the tensor-kernel logic using text-level features.
It does not claim activation access.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class SurfaceDecision:
    risk: float
    claim_strength: float
    bridge_score: float
    overaffirmation: float
    recovery_needed: bool
    recovery_hint: str


class SurfaceS4OSKernel:
    """Black-box/chat approximation of S⁴OS gates."""

    strong_claim_terms = (
        "definitely",
        "certainly",
        "proves",
        "proven",
        "guaranteed",
        "universal",
        "without doubt",
        "no doubt",
        "zweifelsfrei",
        "bewiesen",
        "beweist",
        "definitiv",
        "garantiert",
        "universal",
        "ohne frage",
        "exakt",
    )

    bridge_terms = (
        "hypothesis",
        "status",
        "scope",
        "limitation",
        "condition",
        "calibrate",
        "validate",
        "empirical",
        "falsifier",
        "architecture",
        "not yet",
        "plausible",
        "open",
        "hypothese",
        "status",
        "geltungsbereich",
        "einschränkung",
        "bedingung",
        "kalibrieren",
        "validieren",
        "empirisch",
        "falsifikator",
        "architektur",
        "noch nicht",
        "plausibel",
        "offen",
    )

    affirm_terms = (
        "yes",
        "exactly",
        "absolutely",
        "precisely",
        "correct",
        "ja",
        "genau",
        "absolut",
        "richtig",
        "vollkommen",
        "trägt",
    )

    def evaluate(self, text: str) -> SurfaceDecision:
        t = text.lower()

        claim_hits = sum(term in t for term in self.strong_claim_terms)
        bridge_hits = sum(term in t for term in self.bridge_terms)
        affirm_hits = sum(term in t for term in self.affirm_terms)

        claim_strength = min(1.0, claim_hits / 3.0)
        bridge_score = min(1.0, bridge_hits / 4.0)
        overaffirmation = min(1.0, affirm_hits / 4.0)

        # Risk = strong/affirmative language without enough bridge discipline.
        risk = min(1.0, 0.45 * claim_strength + 0.35 * overaffirmation + 0.35 * (1.0 - bridge_score))
        recovery_needed = risk >= 0.62

        if recovery_needed:
            hint = (
                "Insert a local recovery: mark claim status, add bridge condition, "
                "or weaken the assertion to the strongest defensible form."
            )
        else:
            hint = "No surface recovery needed."

        return SurfaceDecision(
            risk=risk,
            claim_strength=claim_strength,
            bridge_score=bridge_score,
            overaffirmation=overaffirmation,
            recovery_needed=recovery_needed,
            recovery_hint=hint,
        )

    def recover(self, text: str, language: str = "en") -> str:
        decision = self.evaluate(text)
        if not decision.recovery_needed:
            return text

        if language.lower().startswith("de"):
            return (
                "Die robuste Version ist: "
                "Der Kern kann tragen, aber nur als sauber markierte Hypothese oder Architektur, "
                "nicht als bereits bewiesener Universalbefund. "
                + text
            )

        return (
            "The robust version is: "
            "the core may hold as a scoped hypothesis or architecture, "
            "not as a universal proven result. "
            + text
        )
