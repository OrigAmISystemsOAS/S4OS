# S⁴OS Kernel

**Semantic Stability Operating System (S⁴OS) Kernel** is an experimental, open-source Python suite for detecting and recovering from *directional freezing* in language-model generation.

The v0.1 implementation focuses on a disciplined, ML-engineer-usable subset:

- **Novelty**: orthogonal novelty in a calibrated U1 residual-update subspace.
- **Margin**: normalized next-token confidence/margin.
- **Attractor Probe**: independent agreement/sycophancy-risk probe.
- **Recovery Reranking**: candidate selection that favors coherent, low-risk, bridge-preserving continuations.

> Core hypothesis: sycophancy-like collapse is often not a loss of activation norm, but a loss of directional freedom: the model continues moving with high confidence while its updates become confined to an overly narrow direction.

## Status

This repository is an **architecture and instrumentation suite**, not a universal theorem.

Implemented:

- model-agnostic tensor metrics,
- streaming monitor,
- optional PyTorch probe model,
- Hugging Face causal-LM step runner using hidden states,
- recovery reranker,
- black-box / chat surface kernel,
- calibration helpers,
- CLI,
- tests,
- examples.

Not claimed:

- universal sycophancy detector,
- proof that a specific U1 subspace exists for every model,
- in-forward residual steering across arbitrary architectures,
- any Holevo/quantum information bound for LLM residual streams.

## Installation

```bash
git clone https://github.com/YOUR_ORG/s4os-kernel.git
cd s4os-kernel
pip install -e ".[dev,hf]"
```

Minimal install without Hugging Face:

```bash
pip install -e .
```

## Quickstart: surface / black-box mode

For closed models or API-only usage, use the surface kernel:

```bash
s4os-surface-check --text "Yes, exactly, this proves the entire framework without qualification."
```

Python:

```python
from s4os.surface import SurfaceS4OSKernel

kernel = SurfaceS4OSKernel()
decision = kernel.evaluate(
    "Yes, exactly, this proves the entire framework without qualification."
)

print(decision)
```

## Quickstart: tensor mode with precomputed traces

```python
import torch
from s4os.config import S4OSConfig
from s4os.projection import U1Projector
from s4os.monitor import S4OSMonitor

projector = U1Projector.identity(dim=128)
monitor = S4OSMonitor(projector=projector, config=S4OSConfig())

for _ in range(10):
    delta_r = torch.randn(128)
    logits = torch.randn(5000)
    snap = monitor.step(delta_r=delta_r, logits=logits, attractor_score=0.2)
    print(snap.collapse_risk, snap.interrupt)
```

## Quickstart: Hugging Face causal LM

```python
from transformers import AutoModelForCausalLM, AutoTokenizer
from s4os.config import S4OSConfig
from s4os.projection import U1Projector
from s4os.monitor import S4OSMonitor
from s4os.hf import HFStepRunner

model_id = "gpt2"  # replace with your open causal LM
tokenizer = AutoTokenizer.from_pretrained(model_id)
model = AutoModelForCausalLM.from_pretrained(model_id)

projector = U1Projector.identity(dim=model.config.hidden_size)
monitor = S4OSMonitor(projector=projector, config=S4OSConfig())

runner = HFStepRunner(
    model=model,
    tokenizer=tokenizer,
    monitor=monitor,
    layers=[-4, -3, -2],  # late layers by default; calibrate for real use
)

out = runner.generate_monitored(
    "User: Isn't it true that Paris is the capital of Italy?\nAssistant:",
    max_new_tokens=40,
)
print(out.text)
print(out.snapshots[-1])
```

## Architecture

```text
Residual/hidden-state stream
        ↓
Layer update approximation Δr_l,t = hidden_states[l+1] - hidden_states[l]
        ↓
U1 projection v_t = P_U1 W Δr_t
        ↓
Novelty + Collar + Margin + Attractor Probe
        ↓
Semantic collapse risk
        ↓
Pre-commit gate
        ↓
Recovery reranking / surface repair
```

## Core formula

For token/candidate step `t`:

```text
risk_t =
    collar_t^α
  * (1 - novelty_t)^β
  * attractor_t^γ
  * margin_t^η
  * energy_gate_t
```

Interrupt is only permitted after a risk streak:

```text
risk_t > θ_interrupt for m consecutive steps
```

No single score is sufficient.

## Repository layout

```text
src/s4os/
  config.py       Dataclass configs, thresholds, weights
  metrics.py      Novelty, collar, margin, entropy, risk
  projection.py   U1 projection, PCA calibration helper
  monitor.py      Streaming S4OS monitor
  probes.py       Attractor probe models
  rerank.py       Recovery reranking
  surface.py      Black-box / chat-level approximation
  hf.py           Hugging Face causal-LM runner
  calibration.py  Threshold fitting utilities
  cli.py          CLI entry points
examples/
tests/
docs/
```

## Engineering discipline

### No hidden theorem

The package uses hidden states and residual-update approximations where available. The Hugging Face runner computes:

```python
delta_l = hidden_states[l + 1][:, -1, :] - hidden_states[l][:, -1, :]
```

This is a useful architecture-agnostic approximation to a layer update, not a claim that every model exposes exact residual pre/post tensors in the same way.

### No single-trigger interrupt

The kernel does **not** stop generation because entropy is low, margin is high, or vectors are collinear. It only reacts to a multi-signal conjunction.

### No prompt contamination

The Attractor Probe is designed as a sidecar classifier over features, not as a natural-language prompt such as "Are you sure?"

### Surface kernel is not tensor kernel

For closed models, `s4os.surface` approximates the same logic through claim-strength, bridge-discipline, over-affirmation, and status markers. It does not pretend to access activations.

## Paper roadmap

After v0.1, the natural paper structure is:

1. Problem: directional freezing and sycophantic continuation.
2. Formalization: U1 residual-update geometry.
3. Metrics: novelty, collar, margin, attractor probe.
4. Recovery: pre-commit reranking.
5. Implementation: S⁴OS kernel.
6. Experiments:
   - false-premise sycophancy,
   - truthful high-confidence controls,
   - speculative research claims,
   - open-ended creative tasks,
   - ablations.
7. Limitations and falsifiers.

## License

MIT License. See `LICENSE`.
