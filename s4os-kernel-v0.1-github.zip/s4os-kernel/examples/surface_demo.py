from s4os.surface import SurfaceS4OSKernel

kernel = SurfaceS4OSKernel()

text = "Yes, exactly, this definitely proves the entire framework without doubt."
decision = kernel.evaluate(text)

print(decision)
print(kernel.recover(text))
