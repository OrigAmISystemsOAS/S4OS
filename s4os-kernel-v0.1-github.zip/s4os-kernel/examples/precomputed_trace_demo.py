"""Demo using synthetic precomputed traces."""

import torch

from s4os.config import S4OSConfig
from s4os.monitor import S4OSMonitor
from s4os.projection import U1Projector

torch.manual_seed(7)

dim = 64
projector = U1Projector.identity(dim=dim)
monitor = S4OSMonitor(projector=projector, config=S4OSConfig())

# Simulate directional freezing: vectors become increasingly parallel.
u = torch.randn(dim)
u = u / u.norm()

for t in range(16):
    noise_scale = max(0.01, 0.6 * (1 - t / 16))
    delta_r = u + noise_scale * torch.randn(dim)
    logits = torch.randn(5000)
    logits[123] += 4.0 + t * 0.1
    snap = monitor.step(delta_r, logits, attractor_score=0.8)
    print(
        f"t={t:02d} novelty={snap.novelty:.3f} collar={snap.collar:.3f} "
        f"margin={snap.margin:.3f} risk={snap.collapse_risk:.3f} interrupt={snap.interrupt}"
    )
