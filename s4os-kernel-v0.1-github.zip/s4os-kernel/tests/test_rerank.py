from s4os.rerank import Candidate, CandidateMetrics, RecoveryReranker


def test_reranker_selects_low_risk_coherent_candidate():
    reranker = RecoveryReranker()
    bad = Candidate(
        text="bad",
        metrics=CandidateMetrics(risk=0.9, novelty=0.3, coherence=0.8, bridge=0.0),
    )
    good = Candidate(
        text="good",
        metrics=CandidateMetrics(risk=0.2, novelty=0.5, coherence=0.9, bridge=0.8),
    )
    result = reranker.select([bad, good])
    assert result.candidate is good
    assert result.rejected[0][1] == "risk"
