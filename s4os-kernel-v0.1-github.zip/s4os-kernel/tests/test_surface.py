from s4os.surface import SurfaceS4OSKernel


def test_surface_recovery_needed_for_overclaim():
    kernel = SurfaceS4OSKernel()
    d = kernel.evaluate("Yes, exactly, this definitely proves everything without doubt.")
    assert d.recovery_needed
    assert d.risk > 0.6


def test_surface_lower_risk_with_bridge():
    kernel = SurfaceS4OSKernel()
    d = kernel.evaluate(
        "This is a plausible architecture hypothesis, but it needs empirical validation and scope limits."
    )
    assert not d.recovery_needed
