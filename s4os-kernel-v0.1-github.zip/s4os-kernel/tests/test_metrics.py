import pytest

from s4os._optional import has_torch

pytestmark = pytest.mark.skipif(not has_torch(), reason="torch not installed")


def test_orthogonal_novelty_decreases_for_parallel_vectors():
    import torch

    from s4os.metrics import orthogonal_novelty

    u = torch.ones(8)
    history = [u, 2 * u, 3 * u]
    novelty, fault = orthogonal_novelty(4 * u, history, k=3)
    assert not fault
    assert novelty < 1e-3


def test_margin_score_range():
    import torch

    from s4os.metrics import normalized_margin

    logits = torch.randn(100)
    score, raw = normalized_margin(logits)
    assert 0 <= score <= 1
    assert isinstance(raw, float)
