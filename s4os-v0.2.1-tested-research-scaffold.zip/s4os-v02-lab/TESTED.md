# Local Test Report for S4OS v0.2.1

Date: 2026-06-12
Environment: local sandbox, Python 3.13

## Commands run

```bash
python -m compileall -q src tests
PYTHONPATH=src pytest -q
```

Result:

```text
14 passed
```

Editable install was tested after switching the build backend from Hatchling to Setuptools:

```bash
python -m pip install -e . --no-deps
s4os --help
```

Result:

```text
install_ok
s4os CLI available with commands: synthetic, score, report, inspect
```

End-to-end CLI pipeline:

```bash
s4os synthetic --out artifacts_v021/traces/synthetic.jsonl --n-prompts 40 --steps 30 --dim 64 --seed 42
s4os score --traces artifacts_v021/traces/synthetic.jsonl --out artifacts_v021/scores/synthetic_scores.jsonl
s4os report --scores artifacts_v021/scores/synthetic_scores.jsonl --out artifacts_v021/reports/synthetic_report.json
s4os inspect --scores artifacts_v021/scores/synthetic_scores.jsonl --top 5
```

Result:

```text
1200 trace records generated
1200 score records generated
report generated
```

Boundary-discipline check without independent `metadata.attractor_score`:

```text
n_scores: 24
full_risk_values: [None]
warn_count: 0
interrupt_count: 0
```

This confirms that v0.2.1 does not fabricate full risk when no independent attractor score exists.

## Known status

This is a research scaffold, not a production recovery kernel.
Implemented: trace schema, synthetic traces, streaming metric scoring, report generation, CLI, tests.
Not implemented: calibrated attractor probe, validated U1 projection, real pre-commit recovery/reranking on model candidates.
