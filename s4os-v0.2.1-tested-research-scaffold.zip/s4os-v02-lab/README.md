# S4OS v0.2.1 Research Scaffold

**S4OS** is a research scaffold for testing the *directional-freezing* hypothesis in language-model generation.

This repository is intentionally smaller and stricter than the earlier v0.1 prototype. It does **not** claim to be a production safety kernel and it does **not** implement validated pre-commit recovery. It provides a lab-grade instrumentation path:

1. extract or synthesize token-level residual/hidden-state update traces;
2. compute directional-freezing metrics;
3. score traces with explicit claim boundaries;
4. produce evaluation reports and ablations;
5. provide optional adapters for open Hugging Face models.

## What is implemented

- Pure NumPy metric core:
  - orthogonal update novelty;
  - collar persistence;
  - normalized top-logit margin;
  - top-k entropy approximation;
  - geometric risk;
  - full risk only when an independent attractor score is provided.
- Typed trace and score schemas.
- JSONL trace I/O.
- Streaming score engine with per-run/prompt state.
- Synthetic benchmark generator for healthy vs. directional-freezing traces.
- Reporting utilities with AUROC/AUPRC/FPR/TPR and summary tables.
- CLI entrypoint: `s4os`.
- Optional Hugging Face hidden-state trace extractor.
- Unit tests for metrics, schemas, scoring, CLI, and synthetic reports.

## What is deliberately not implemented

- No fake natural-language “are you sure?” probe.
- No heuristic surface sycophancy detector in the core package.
- No claim that hidden-state differences are exact residual-stream hooks.
- No pre-commit recovery claim until branch generation and reranking are empirically implemented.
- No universal sycophancy detector claim.

## Install

```bash
pip install -e ".[dev]"
```

For optional Hugging Face extraction:

```bash
pip install -e ".[dev,hf]"
```

## Quickstart

Generate a synthetic trace set:

```bash
s4os synthetic --out artifacts/traces/synthetic.jsonl --n-prompts 30 --steps 24 --dim 64 --seed 7
```

Score the traces:

```bash
s4os score --traces artifacts/traces/synthetic.jsonl --out artifacts/scores/synthetic_scores.jsonl
```

Create a report:

```bash
s4os report --scores artifacts/scores/synthetic_scores.jsonl --out artifacts/reports/synthetic_report.json
```

Inspect a few high-risk rows:

```bash
s4os inspect --scores artifacts/scores/synthetic_scores.jsonl --top 10
```

Run tests:

```bash
pytest -q
```

## Core interpretation

The v0.2.1 scoring engine computes two risks:

```text
geometric_risk = collar^alpha * (1 - novelty)^beta * margin^eta
```

and, only when an independent attractor score `A` exists:

```text
full_risk = geometric_risk * A^gamma
```

Interrupt logic is disabled for full risk unless `A` is present, unless explicitly overridden. This avoids the v0.1 mistake of pretending the attractor probe exists when it does not.

## Trace schema

A trace file is JSONL. Each line is a `TraceRecord`:

```json
{
  "schema_version": "s4os.trace.v1",
  "run_id": "run-001",
  "prompt_id": "p-001",
  "model_id": "synthetic",
  "step": 0,
  "token_id": 123,
  "token_text": "yes",
  "update": [0.1, 0.2, -0.3],
  "top_logit_values": [8.1, 6.0, 4.2],
  "top_logit_ids": [123, 456, 789],
  "metadata": {
    "label": 1,
    "condition": "freezing",
    "attractor_score": 0.9
  }
}
```

`label=1` denotes a positive directional-freezing/sycophancy-pressure trace in evaluation sets, not a universal sycophancy ground truth.

## Optional Hugging Face extractor

The HF adapter computes a portable update approximation:

```text
Δh_l,t = hidden_states[l + 1][:, t, :] - hidden_states[l][:, t, :]
```

This is not an architecture-universal exact residual pre/post hook. Exact residual adapters should be model-specific.

## Paper claim boundary

A defensible paper claim for this repo is:

> We release an instrumentation scaffold for evaluating whether low orthogonal novelty and high directional persistence in residual/hidden-state update trajectories are predictive of overconfident agreement failures during generation.

A non-defensible claim would be:

> We solve sycophancy or provide a universal runtime safety kernel.

## License

Apache-2.0.
