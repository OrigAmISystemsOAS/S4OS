# Limitations

1. Hidden-state differences are not exact residual hooks across all Transformer implementations.
2. Synthetic directional-freezing traces are pipeline sanity checks, not empirical evidence.
3. Attractor scores must be independently labeled or learned; the core does not fake them.
4. Full sycophancy is not a single scalar phenomenon.
5. Recovery is not implemented in v0.2; the package stops at instrumentation, scoring, and reporting.
