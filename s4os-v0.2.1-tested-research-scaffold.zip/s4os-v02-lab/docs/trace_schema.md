# Trace Schema

Trace files are JSONL. Each line is one token-step record.

Required fields:

- `schema_version`: must be `s4os.trace.v1`
- `run_id`
- `prompt_id`
- `model_id`
- `step`
- `update`: numeric vector
- `top_logit_values`: at least two numeric logits

Optional fields:

- `top_logit_ids`
- `token_id`
- `token_text`
- `condition`
- `label`
- `metadata`

If `metadata.attractor_score` is present, full risk can be computed.
