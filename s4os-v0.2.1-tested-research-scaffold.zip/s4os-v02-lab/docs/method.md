# Method Notes

S4OS v0.2 tests a narrow hypothesis:

> Overconfident agreement failures may be preceded by low orthogonal novelty and high directional persistence in hidden/residual update trajectories.

The method does not equate this signature with sycophancy by definition. It only provides measurable quantities and an evaluation harness.

## Metrics

- Novelty: orthogonal component outside the span of recent updates.
- Collar: mean cosine similarity to recent updates.
- Margin: normalized top1-top2 logit gap.
- Attractor: optional independent label/probe score. Not synthesized inside the core except in synthetic benchmarks.

## Risk boundary

Geometric risk can be computed without an attractor score, but full risk and interrupts require an attractor score by default. This is a deliberate anti-leap constraint.
