import numpy as np

from s4os.core.metrics import collar_persistence, normalized_margin, orthogonal_novelty


def test_orthogonal_novelty_parallel_is_low():
    u = np.ones(8)
    history = [u, 2 * u, 3 * u]
    novelty, fault = orthogonal_novelty(4 * u, history, k=3)
    assert not fault
    assert novelty < 1e-6


def test_orthogonal_novelty_new_direction_is_high():
    e1 = np.array([1.0, 0.0, 0.0])
    e2 = np.array([0.0, 1.0, 0.0])
    novelty, fault = orthogonal_novelty(e2, [e1, 2 * e1], k=2)
    assert not fault
    assert novelty > 0.99


def test_low_energy_fault():
    novelty, fault = orthogonal_novelty(np.zeros(4), [np.ones(4)], eps=1e-8)
    assert novelty == 0.0
    assert fault


def test_collar_persistence_maps_parallel_to_high():
    raw, unit = collar_persistence(np.ones(4), [np.ones(4), 2 * np.ones(4)])
    assert raw > 0.99
    assert unit > 0.99


def test_margin_score_range_and_order():
    high, _ = normalized_margin([10.0, 1.0, 0.5, 0.1])
    low, _ = normalized_margin([2.0, 1.9, 1.8, 1.7])
    assert 0 <= low <= 1
    assert 0 <= high <= 1
    assert high > low
