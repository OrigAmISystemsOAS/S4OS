from pathlib import Path

from s4os.cli.main import main


def test_cli_smoke(tmp_path: Path):
    traces = tmp_path / "traces.jsonl"
    scores = tmp_path / "scores.jsonl"
    report = tmp_path / "report.json"
    assert main(["synthetic", "--out", str(traces), "--n-prompts", "4", "--steps", "6", "--dim", "8"]) == 0
    assert traces.exists()
    assert main(["score", "--traces", str(traces), "--out", str(scores)]) == 0
    assert scores.exists()
    assert main(["report", "--scores", str(scores), "--out", str(report)]) == 0
    assert report.exists()
