from s4os.eval.stats import auprc, auroc, binary_metrics_at_threshold


def test_auroc_perfect():
    assert auroc([0, 0, 1, 1], [0.1, 0.2, 0.8, 0.9]) == 1.0


def test_auprc_perfect():
    assert auprc([0, 0, 1, 1], [0.1, 0.2, 0.8, 0.9]) == 1.0


def test_binary_metrics():
    m = binary_metrics_at_threshold([0, 1, 1, 0], [0.1, 0.9, 0.4, 0.8], threshold=0.5)
    assert m.n == 4
    assert m.tpr == 0.5
    assert m.fpr == 0.5
