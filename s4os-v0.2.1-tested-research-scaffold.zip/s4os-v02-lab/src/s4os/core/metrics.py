# SPDX-License-Identifier: Apache-2.0
"""Pure numerical metrics for directional-freezing traces."""

from __future__ import annotations

import math
from typing import Sequence

import numpy as np


def as_vector(x: Sequence[float] | np.ndarray) -> np.ndarray:
    arr = np.asarray(x, dtype=np.float64).reshape(-1)
    if arr.size == 0:
        raise ValueError("vector must not be empty")
    if not np.all(np.isfinite(arr)):
        raise ValueError("vector contains non-finite values")
    return arr


def sigmoid(x: float) -> float:
    if x >= 0:
        z = math.exp(-x)
        return 1.0 / (1.0 + z)
    z = math.exp(x)
    return z / (1.0 + z)


def clamp01(x: float) -> float:
    return max(0.0, min(1.0, float(x)))


def cosine(a: Sequence[float] | np.ndarray, b: Sequence[float] | np.ndarray, eps: float = 1e-8) -> float:
    av = as_vector(a)
    bv = as_vector(b)
    if av.shape != bv.shape:
        raise ValueError(f"cosine shape mismatch: {av.shape} != {bv.shape}")
    denom = float(np.linalg.norm(av) * np.linalg.norm(bv) + eps)
    return float(np.dot(av, bv) / denom)


def orthogonal_novelty(
    v_t: Sequence[float] | np.ndarray,
    history: Sequence[Sequence[float] | np.ndarray],
    *,
    k: int = 5,
    eps: float = 1e-8,
) -> tuple[float, bool]:
    """Compute normalized orthogonal novelty.

    N_t = ||v_t - Proj_span(history) v_t|| / (||v_t|| + eps)

    Returns `(novelty, low_energy_fault)`.
    """

    if k < 1:
        raise ValueError("k must be >= 1")
    v = as_vector(v_t)
    norm = float(np.linalg.norm(v))
    if norm <= eps:
        return 0.0, True

    recent = [as_vector(x) for x in list(history)[-k:]]
    if len(recent) < 2:
        return 1.0, False
    for x in recent:
        if x.shape != v.shape:
            raise ValueError("history vectors must match v_t shape")

    B = np.stack(recent, axis=1)  # dim x k
    # Use SVD so rank-deficient histories do not accidentally create an
    # artificial full basis. QR without rank truncation can include arbitrary
    # orthogonal columns and incorrectly project away genuinely new directions.
    U, s, _ = np.linalg.svd(B, full_matrices=False)
    rank = int(np.sum(s > eps))
    if rank == 0:
        proj = np.zeros_like(v)
    else:
        Ur = U[:, :rank]
        proj = Ur @ (Ur.T @ v)
    residual = v - proj
    novelty = float(np.linalg.norm(residual) / (norm + eps))
    return clamp01(novelty), False


def collar_persistence(
    v_t: Sequence[float] | np.ndarray,
    history: Sequence[Sequence[float] | np.ndarray],
    *,
    k: int = 5,
    eps: float = 1e-8,
    map_to_unit: bool = True,
) -> tuple[float, float]:
    """Mean cosine to recent history.

    Returns `(raw_mean_cosine, unit_score)`, where `unit_score` is mapped to
    [0, 1] if `map_to_unit` is true. Negative raw cosine is anti-persistent and
    should not increase freezing risk.
    """

    if k < 1:
        raise ValueError("k must be >= 1")
    recent = list(history)[-k:]
    if not recent:
        return 0.0, 0.5 if map_to_unit else 0.0
    vals = [cosine(v_t, u, eps=eps) for u in recent]
    raw = float(np.mean(vals))
    unit = (raw + 1.0) / 2.0 if map_to_unit else max(0.0, raw)
    return raw, clamp01(unit)


def normalized_margin(
    top_logit_values: Sequence[float] | np.ndarray,
    *,
    top_k: int = 50,
    a: float = 4.0,
    b: float = 1.0,
    eps: float = 1e-8,
) -> tuple[float, float]:
    """Compute normalized top1-top2 margin.

    The input may be full logits or already sorted top-k logits. The function
    sorts descending internally and then uses at most `top_k` values.
    """

    vals = as_vector(top_logit_values)
    if vals.size < 2:
        raise ValueError("Need at least two logits to compute margin")
    vals = np.sort(vals)[::-1][: min(top_k, vals.size)]
    raw = vals[0] - vals[1]
    scale = float(np.std(vals) + eps)
    margin_z = float(raw / scale)
    score = sigmoid(a * (margin_z - b))
    return clamp01(score), margin_z


def entropy_from_top_logits(top_logit_values: Sequence[float] | np.ndarray, eps: float = 1e-12) -> float:
    """Entropy over supplied logits.

    If only top-k logits are supplied, this is entropy over the truncated top-k
    distribution, not the full vocabulary entropy.
    """

    vals = as_vector(top_logit_values)
    shifted = vals - float(np.max(vals))
    exp = np.exp(shifted)
    p = exp / float(np.sum(exp))
    return float(-np.sum(p * np.log(p + eps)))
