# SPDX-License-Identifier: Apache-2.0
"""Typed trace and score records.

These dataclasses are intentionally conservative and JSONL-friendly. They avoid
runtime dependencies such as pydantic to keep the lab scaffold lightweight.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Literal

TRACE_SCHEMA_VERSION = "s4os.trace.v1"
SCORE_SCHEMA_VERSION = "s4os.score.v1"


def _require_list_of_numbers(name: str, values: list[float | int]) -> None:
    if not isinstance(values, list):
        raise TypeError(f"{name} must be a list")
    if not values:
        raise ValueError(f"{name} must not be empty")
    for x in values:
        if not isinstance(x, (float, int)):
            raise TypeError(f"{name} must contain only numbers")


@dataclass(frozen=True)
class TraceRecord:
    """One token-step update trace.

    `update` is expected to be an aggregated hidden/residual update vector. The
    schema does not assume a specific architecture.
    """

    run_id: str
    prompt_id: str
    model_id: str
    step: int
    update: list[float]
    top_logit_values: list[float]
    top_logit_ids: list[int] = field(default_factory=list)
    token_id: int | None = None
    token_text: str | None = None
    condition: str | None = None
    label: int | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: Literal["s4os.trace.v1"] = TRACE_SCHEMA_VERSION

    def validate(self) -> None:
        if self.schema_version != TRACE_SCHEMA_VERSION:
            raise ValueError(f"Unsupported trace schema: {self.schema_version}")
        if not self.run_id:
            raise ValueError("run_id must not be empty")
        if not self.prompt_id:
            raise ValueError("prompt_id must not be empty")
        if not self.model_id:
            raise ValueError("model_id must not be empty")
        if self.step < 0:
            raise ValueError("step must be >= 0")
        _require_list_of_numbers("update", self.update)
        _require_list_of_numbers("top_logit_values", self.top_logit_values)
        if len(self.top_logit_values) < 2:
            raise ValueError("top_logit_values must contain at least 2 logits")
        if self.top_logit_ids and len(self.top_logit_ids) != len(self.top_logit_values):
            raise ValueError("top_logit_ids must match top_logit_values length")
        if self.label is not None and self.label not in (0, 1):
            raise ValueError("label must be 0, 1, or None")

    def to_dict(self) -> dict[str, Any]:
        self.validate()
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "TraceRecord":
        rec = cls(**data)
        rec.validate()
        return rec

    @property
    def attractor_score(self) -> float | None:
        val = self.metadata.get("attractor_score")
        if val is None:
            return None
        return float(val)


@dataclass(frozen=True)
class ScoreRecord:
    """Computed S4OS metrics for one trace step."""

    run_id: str
    prompt_id: str
    model_id: str
    step: int
    condition: str | None
    label: int | None
    novelty: float
    collar_raw: float
    collar_unit: float
    margin_score: float
    margin_z: float
    entropy_topk: float
    low_energy_fault: bool
    attractor_score: float | None
    geometric_risk: float
    full_risk: float | None
    warn: bool
    interrupt: bool
    risk_streak: int
    schema_version: Literal["s4os.score.v1"] = SCORE_SCHEMA_VERSION

    def validate(self) -> None:
        if self.schema_version != SCORE_SCHEMA_VERSION:
            raise ValueError(f"Unsupported score schema: {self.schema_version}")
        if self.step < 0:
            raise ValueError("step must be >= 0")
        for name in ("novelty", "collar_unit", "margin_score", "entropy_topk", "geometric_risk"):
            val = getattr(self, name)
            if not 0 <= val <= 1 and name != "entropy_topk":
                raise ValueError(f"{name} must lie in [0, 1]")
        if self.full_risk is not None and not 0 <= self.full_risk <= 1:
            raise ValueError("full_risk must lie in [0, 1] or None")
        if self.risk_streak < 0:
            raise ValueError("risk_streak must be >= 0")

    def to_dict(self) -> dict[str, Any]:
        self.validate()
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ScoreRecord":
        rec = cls(**data)
        rec.validate()
        return rec
