# SPDX-License-Identifier: Apache-2.0
"""Risk composition functions."""

from __future__ import annotations

from s4os.core.metrics import clamp01


def compose_geometric_risk(
    *,
    novelty: float,
    collar_unit: float,
    margin_score: float,
    alpha_collar: float = 1.5,
    beta_low_novelty: float = 1.2,
    eta_margin: float = 0.8,
    energy_gate: bool = True,
) -> float:
    """Risk available without an independent attractor probe."""

    if not energy_gate:
        return 0.0
    risk = (
        clamp01(collar_unit) ** alpha_collar
        * (1.0 - clamp01(novelty)) ** beta_low_novelty
        * clamp01(margin_score) ** eta_margin
    )
    return clamp01(risk)


def compose_full_risk(
    *,
    geometric_risk: float,
    attractor_score: float | None,
    gamma_attractor: float = 1.5,
) -> float | None:
    """Full risk; unavailable when no independent attractor score exists."""

    if attractor_score is None:
        return None
    return clamp01(clamp01(geometric_risk) * clamp01(attractor_score) ** gamma_attractor)
