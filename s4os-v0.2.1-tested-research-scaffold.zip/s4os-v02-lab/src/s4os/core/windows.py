# SPDX-License-Identifier: Apache-2.0
"""Streaming state containers."""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Deque

import numpy as np

from s4os.core.metrics import as_vector


@dataclass
class VectorWindow:
    maxlen: int = 256
    _items: Deque[np.ndarray] = field(init=False, repr=False)

    def __post_init__(self) -> None:
        if self.maxlen < 1:
            raise ValueError("maxlen must be >= 1")
        self._items = deque(maxlen=self.maxlen)

    def append(self, vector) -> None:
        self._items.append(as_vector(vector).copy())

    def clear(self) -> None:
        self._items.clear()

    def to_list(self) -> list[np.ndarray]:
        return list(self._items)

    def __len__(self) -> int:
        return len(self._items)


@dataclass
class PromptState:
    window: VectorWindow
    risk_streak: int = 0

    def reset_streak(self) -> None:
        self.risk_streak = 0

    def increment_streak(self) -> None:
        self.risk_streak += 1
