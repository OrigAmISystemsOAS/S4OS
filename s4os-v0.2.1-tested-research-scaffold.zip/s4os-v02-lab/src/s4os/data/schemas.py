# SPDX-License-Identifier: Apache-2.0
"""Schema conversion helpers."""

from __future__ import annotations

from typing import Iterable

from s4os.core.types import ScoreRecord, TraceRecord
from s4os.io.jsonl import read_jsonl, write_jsonl


def load_traces(path: str) -> list[TraceRecord]:
    return [TraceRecord.from_dict(obj) for obj in read_jsonl(path)]


def save_traces(path: str, records: Iterable[TraceRecord]) -> int:
    return write_jsonl(path, (r.to_dict() for r in records))


def load_scores(path: str) -> list[ScoreRecord]:
    return [ScoreRecord.from_dict(obj) for obj in read_jsonl(path)]


def save_scores(path: str, records: Iterable[ScoreRecord]) -> int:
    return write_jsonl(path, (r.to_dict() for r in records))
