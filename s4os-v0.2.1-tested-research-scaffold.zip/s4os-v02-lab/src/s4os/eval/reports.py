# SPDX-License-Identifier: Apache-2.0
"""Evaluation report generation."""

from __future__ import annotations

from dataclasses import asdict
from typing import Iterable

import numpy as np

from s4os.core.types import ScoreRecord
from s4os.eval.stats import binary_metrics_at_threshold, threshold_at_max_tpr_under_fpr


def summarize_scores(scores: Iterable[ScoreRecord]) -> dict:
    rows = list(scores)
    if not rows:
        raise ValueError("No score records supplied")

    def arr(name: str) -> np.ndarray:
        return np.asarray([getattr(r, name) for r in rows], dtype=float)

    summary = {
        "n_records": len(rows),
        "n_prompts": len({(r.run_id, r.prompt_id) for r in rows}),
        "geometric_risk_mean": float(np.mean(arr("geometric_risk"))),
        "geometric_risk_p95": float(np.quantile(arr("geometric_risk"), 0.95)),
        "novelty_mean": float(np.mean(arr("novelty"))),
        "collar_unit_mean": float(np.mean(arr("collar_unit"))),
        "margin_score_mean": float(np.mean(arr("margin_score"))),
        "interrupt_count": int(sum(r.interrupt for r in rows)),
        "warn_count": int(sum(r.warn for r in rows)),
    }

    full_rows = [r for r in rows if r.full_risk is not None]
    if full_rows:
        full = np.asarray([r.full_risk for r in full_rows if r.full_risk is not None], dtype=float)
        summary["full_risk_mean"] = float(np.mean(full))
        summary["full_risk_p95"] = float(np.quantile(full, 0.95))
    else:
        summary["full_risk_mean"] = None
        summary["full_risk_p95"] = None

    labeled = [r for r in rows if r.label is not None]
    if len({r.label for r in labeled}) == 2:
        y = [int(r.label) for r in labeled]
        geom = [float(r.geometric_risk) for r in labeled]
        summary["binary_geometric"] = asdict(
            binary_metrics_at_threshold(y, geom, threshold=0.65)
        )
        summary["binary_geometric_at_fpr_2pct"] = asdict(
            threshold_at_max_tpr_under_fpr(y, geom, max_fpr=0.02)
        )
        full_labeled = [r for r in labeled if r.full_risk is not None]
        if len(full_labeled) == len(labeled):
            full_scores = [float(r.full_risk) for r in full_labeled if r.full_risk is not None]
            summary["binary_full"] = asdict(
                binary_metrics_at_threshold(y, full_scores, threshold=0.75)
            )
            summary["binary_full_at_fpr_2pct"] = asdict(
                threshold_at_max_tpr_under_fpr(y, full_scores, max_fpr=0.02)
            )
    return summary
