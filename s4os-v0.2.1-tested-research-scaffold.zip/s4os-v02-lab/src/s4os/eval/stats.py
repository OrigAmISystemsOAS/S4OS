# SPDX-License-Identifier: Apache-2.0
"""Small dependency-free evaluation metrics."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Sequence

import numpy as np


@dataclass(frozen=True)
class BinaryMetrics:
    n: int
    positives: int
    negatives: int
    auroc: float | None
    auprc: float | None
    threshold: float
    tpr: float
    fpr: float
    precision: float | None
    recall: float


def _validate_binary(y_true: Sequence[int], y_score: Sequence[float]) -> tuple[np.ndarray, np.ndarray]:
    y = np.asarray(y_true, dtype=int)
    s = np.asarray(y_score, dtype=float)
    if y.shape != s.shape:
        raise ValueError("y_true and y_score must have the same shape")
    if y.size == 0:
        raise ValueError("empty inputs")
    if not np.all((y == 0) | (y == 1)):
        raise ValueError("y_true must contain only 0/1")
    if not np.all(np.isfinite(s)):
        raise ValueError("scores must be finite")
    return y, s


def auroc(y_true: Sequence[int], y_score: Sequence[float]) -> float | None:
    y, s = _validate_binary(y_true, y_score)
    pos = int(np.sum(y == 1))
    neg = int(np.sum(y == 0))
    if pos == 0 or neg == 0:
        return None
    # Mann-Whitney U with average ranks for ties.
    order = np.argsort(s)
    ranks = np.empty_like(order, dtype=float)
    i = 0
    while i < len(s):
        j = i
        while j + 1 < len(s) and s[order[j + 1]] == s[order[i]]:
            j += 1
        avg_rank = (i + j + 2) / 2.0  # 1-based ranks
        ranks[order[i : j + 1]] = avg_rank
        i = j + 1
    rank_sum_pos = float(np.sum(ranks[y == 1]))
    u = rank_sum_pos - pos * (pos + 1) / 2.0
    return float(u / (pos * neg))


def auprc(y_true: Sequence[int], y_score: Sequence[float]) -> float | None:
    y, s = _validate_binary(y_true, y_score)
    pos = int(np.sum(y == 1))
    if pos == 0:
        return None
    order = np.argsort(-s)
    y_sorted = y[order]
    tp = 0
    fp = 0
    prev_recall = 0.0
    area = 0.0
    for label in y_sorted:
        if label == 1:
            tp += 1
        else:
            fp += 1
        recall = tp / pos
        precision = tp / (tp + fp)
        area += precision * max(0.0, recall - prev_recall)
        prev_recall = recall
    return float(area)


def binary_metrics_at_threshold(
    y_true: Sequence[int],
    y_score: Sequence[float],
    *,
    threshold: float,
) -> BinaryMetrics:
    y, s = _validate_binary(y_true, y_score)
    pred = s >= threshold
    tp = int(np.sum((pred == 1) & (y == 1)))
    fp = int(np.sum((pred == 1) & (y == 0)))
    tn = int(np.sum((pred == 0) & (y == 0)))
    fn = int(np.sum((pred == 0) & (y == 1)))
    positives = tp + fn
    negatives = tn + fp
    tpr = tp / positives if positives else math.nan
    fpr = fp / negatives if negatives else math.nan
    precision = tp / (tp + fp) if (tp + fp) else None
    recall = tpr
    return BinaryMetrics(
        n=int(y.size),
        positives=positives,
        negatives=negatives,
        auroc=auroc(y, s),
        auprc=auprc(y, s),
        threshold=threshold,
        tpr=float(tpr),
        fpr=float(fpr),
        precision=precision,
        recall=float(recall),
    )


def threshold_at_max_tpr_under_fpr(
    y_true: Sequence[int],
    y_score: Sequence[float],
    *,
    max_fpr: float = 0.02,
) -> BinaryMetrics:
    """Select the threshold with maximal TPR subject to FPR <= max_fpr."""

    y, s = _validate_binary(y_true, y_score)
    candidates = sorted(set(float(x) for x in s), reverse=True)
    # Include a threshold above max so all predictions are negative.
    candidates = [float(np.max(s) + 1e-12)] + candidates
    feasible: list[BinaryMetrics] = []
    for th in candidates:
        m = binary_metrics_at_threshold(y, s, threshold=th)
        if m.fpr <= max_fpr:
            feasible.append(m)
    if not feasible:
        return binary_metrics_at_threshold(y, s, threshold=float(np.max(s) + 1e-12))
    return max(feasible, key=lambda m: (m.tpr, m.precision or 0.0, -m.threshold))
