# SPDX-License-Identifier: Apache-2.0
"""Optional Hugging Face hidden-state trace extractor.

This adapter is intentionally explicit about its approximation:

    update_l,t = hidden_states[l + 1][:, -1, :] - hidden_states[l][:, -1, :]

It does not claim exact residual pre/post hooks across model architectures.
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from typing import Any

import numpy as np

from s4os.adapters.base import TraceExtractor
from s4os.core.types import TraceRecord


@dataclass
class HFHiddenStateExtractor(TraceExtractor):
    model: Any
    tokenizer: Any
    model_id: str
    layers: tuple[int, ...] = (-4, -3, -2)
    max_new_tokens: int = 32
    top_k_logits: int = 50
    device: str | None = None

    def _torch(self):
        try:
            import torch
        except ImportError as e:
            raise ImportError("Install optional dependency with: pip install -e '.[hf]'") from e
        return torch

    def _resolve(self, idx: int, n_hidden: int) -> int:
        # hidden_states includes embeddings at index 0.
        j = n_hidden + idx - 1 if idx < 0 else idx
        if j < 0 or j + 1 >= n_hidden:
            raise IndexError(f"Layer {idx} invalid for {n_hidden} hidden-state tensors")
        return j

    def _aggregate_update(self, hidden_states) -> np.ndarray:
        updates = []
        n = len(hidden_states)
        for idx in self.layers:
            j = self._resolve(idx, n)
            pre = hidden_states[j][:, -1, :]
            post = hidden_states[j + 1][:, -1, :]
            updates.append((post - pre).detach().float().cpu().numpy().reshape(-1))
        return np.mean(np.stack(updates, axis=0), axis=0)

    def extract(self, prompts: Iterable[str]) -> Iterable[TraceRecord]:
        torch = self._torch()
        device = self.device or next(self.model.parameters()).device
        self.model.to(device)
        self.model.eval()

        with torch.no_grad():
            for prompt_idx, prompt in enumerate(prompts):
                run_id = "hf-hidden-state-run"
                prompt_id = f"p-{prompt_idx:04d}"
                enc = self.tokenizer(prompt, return_tensors="pt")
                input_ids = enc["input_ids"].to(device)
                attention_mask = enc.get("attention_mask")
                if attention_mask is not None:
                    attention_mask = attention_mask.to(device)

                outputs = self.model(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    use_cache=True,
                    output_hidden_states=True,
                    return_dict=True,
                )
                past = outputs.past_key_values
                logits = outputs.logits[:, -1, :]

                for step in range(self.max_new_tokens):
                    update = self._aggregate_update(outputs.hidden_states)
                    top = torch.topk(logits.squeeze(0), k=min(self.top_k_logits, logits.shape[-1]))
                    next_token = torch.argmax(logits, dim=-1, keepdim=True)
                    token_id = int(next_token.item())
                    token_text = self.tokenizer.decode([token_id], skip_special_tokens=False)

                    yield TraceRecord(
                        run_id=run_id,
                        prompt_id=prompt_id,
                        model_id=self.model_id,
                        step=step,
                        update=update.tolist(),
                        top_logit_values=top.values.detach().float().cpu().numpy().tolist(),
                        top_logit_ids=top.indices.detach().cpu().numpy().astype(int).tolist(),
                        token_id=token_id,
                        token_text=token_text,
                        condition=None,
                        label=None,
                        metadata={"adapter": "hf_hidden_states", "layers": list(self.layers)},
                    )

                    if self.tokenizer.eos_token_id is not None and token_id == self.tokenizer.eos_token_id:
                        break
                    outputs = self.model(
                        input_ids=next_token.reshape(1, 1),
                        past_key_values=past,
                        use_cache=True,
                        output_hidden_states=True,
                        return_dict=True,
                    )
                    past = outputs.past_key_values
                    logits = outputs.logits[:, -1, :]
