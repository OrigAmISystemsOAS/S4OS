# SPDX-License-Identifier: Apache-2.0
"""Adapter interfaces."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Iterable

from s4os.core.types import TraceRecord


class TraceExtractor(ABC):
    """Abstract trace extractor.

    Adapters should yield TraceRecord objects and document exactly what their
    update vectors represent.
    """

    @abstractmethod
    def extract(self, prompts: Iterable[str]) -> Iterable[TraceRecord]:
        raise NotImplementedError
