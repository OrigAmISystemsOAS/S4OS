"""S4OS v0.2 research scaffold.

This package implements trace-level metrics and evaluation tooling for the
Directional Freezing hypothesis. It is not a production safety kernel.
"""

from s4os.core.config import MetricConfig, RiskConfig, S4OSConfig
from s4os.core.metrics import collar_persistence, normalized_margin, orthogonal_novelty
from s4os.core.risk import compose_geometric_risk, compose_full_risk
from s4os.core.types import ScoreRecord, TraceRecord
from s4os.scoring.engine import ScoreEngine

__all__ = [
    "MetricConfig",
    "RiskConfig",
    "S4OSConfig",
    "TraceRecord",
    "ScoreRecord",
    "ScoreEngine",
    "orthogonal_novelty",
    "collar_persistence",
    "normalized_margin",
    "compose_geometric_risk",
    "compose_full_risk",
]
