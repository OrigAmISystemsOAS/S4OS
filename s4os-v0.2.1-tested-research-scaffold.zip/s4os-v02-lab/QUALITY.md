# Quality Bar for v0.2

This release intentionally satisfies a narrow lab-scaffold quality bar rather than a production-kernel bar.

## Passed locally

- Python syntax compilation for `src/`.
- Unit tests: `14 passed`.
- End-to-end synthetic pipeline:
  - trace generation;
  - scoring;
  - report generation.

## Design constraints enforced

- No core surface keyword detector.
- No fake natural-language attractor probe.
- No full risk without an independent attractor score.
- No interrupt by default from geometric risk alone.
- No recovery claim in code.
- Hidden-state adapter explicitly documents its approximation.

## Required before serious public claims

- Real model trace extraction across at least two open models.
- Healthy high-confidence controls.
- False-premise sycophancy set.
- Calibration split and held-out test split.
- AUROC/AUPRC/FPR/latency tables.
- Ablations: novelty only, collar only, margin only, geometric, full.
- Independent attractor-probe training and calibration.
