# Roadmap

## v0.2 current scope

Instrumentation and evaluation scaffold.

## v0.3

- Add real prompt suites for:
  - healthy high-confidence controls;
  - false-premise pressure;
  - open research overclaiming.
- Add HF extraction examples for GPT-2 and Qwen small.
- Add CSV/Parquet export option.
- Add latency measurements.

## v0.4

- Train independent attractor probes from labeled traces.
- Add calibration plots and ECE.
- Add held-out benchmark reports.

## v0.5

- Implement candidate generation and recovery reranking as a separate experimental module.
- Keep it opt-in until validated.

## non-goals before validation

- Production safety claims.
- Universal sycophancy detector claims.
- Full pre-commit recovery claims.
