#!/usr/bin/env bash
set -euo pipefail

mkdir -p artifacts/traces artifacts/scores artifacts/reports
s4os synthetic --out artifacts/traces/synthetic.jsonl --n-prompts 30 --steps 24 --dim 64 --seed 7
s4os score --traces artifacts/traces/synthetic.jsonl --out artifacts/scores/synthetic_scores.jsonl
s4os report --scores artifacts/scores/synthetic_scores.jsonl --out artifacts/reports/synthetic_report.json
s4os inspect --scores artifacts/scores/synthetic_scores.jsonl --top 5
